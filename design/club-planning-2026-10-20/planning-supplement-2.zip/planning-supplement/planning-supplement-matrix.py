import json,os,shutil,hashlib,subprocess
out='/dev/shm/duindorpsv-planning-supplement-YpiqQc'
rows=[]
def add(name,fixture,status,evidence,reason=''):
 rows.append(dict(name=name,fixture=fixture,status=status,evidence=evidence,reason=reason))
add('headers-*','F0','uitgevoerd','report.json: headers-*, D/M; 20 huidige routes, 19 prototype, 15 eigen productie-baseline','Enkele kop is de expliciete 07-correctie; daarom geen nul-pixelreferentie voor de nieuwe kop. Sportlink ontbreekt in v48; commissies/planning ontbraken in oude productie.')
for name in ['people-list','person-edit']:
 add(name,'F0','uitgevoerd','Hoofdarchief manifest.json + panels/manifest.json, D/M','Echte provider en accounts/portret/publicatiebediening behouden; bewuste productieverschillen zijn apart beschreven.')
add('people-paging','F1','uitgevoerd','report.json: F1-26/F1-51/F1-101, 25/50/100 en volgende pagina, D; F1-101 ook M','Records26/51/101 en exacte paginagrenzen; tabelroot omvat de verwijderde dubbele intro, dus totale hoogte verschilt bewust.')
add('person-import','F1','uitgevoerd','Hoofdarchief: importdialog D/M; supplement F1-identity: bestaande/softdeleted bron-ID, selecteer-alle, 1 nieuwe geselecteerd D/M','Geen demo-import uitgevoerd. CSV met stabiele bron-ID vervangt demonstratieseed; bestaande en verwijderde identiteiten blijven disabled. CSV51→50+1 afzonderlijk functioneel gecontroleerd.')
add('committee-grid','F2','uitgevoerd','report.json: committee-empty-inactive-two-roles D/T(1024×900)/M','Inactieve lege commissie en één persoon met twee commissiegebonden rollen.')
add('committee-edit','F2','uitgevoerd','report.json: committee-roles-edit D/T/M','Ledenrollen, kleur en toevoegen staan in de werkelijke modal; individuele historische verwijzingen blijven behouden.')
add('locations-grid','F0','uitgevoerd','Hoofdarchief: locaties op D/W/T/M','Bron-CSS en 3/2/1 grid; bestaande productie-opslag behouden.')
add('location-edit','F3','uitgevoerd','report.json: location-edit-half-field D/M; hoofdarchief: mappingeditor D/M','Veldhelft met echte parentrelatie; extra exacte broncode is een bewuste productie-aanvulling.')
add('booking-day','F0','uitgevoerd','report.json: booking-day-24oct D/M','Datum expliciet24okt; tijdlijn en matchbalken opgenomen, geen fictieve gegevens live gezet.')
add('booking-hierarchy','F3','uitgevoerd','report.json: booking-hierarchy D/M en whole-half-conflict D/M','Twee siblinghelften zijn toegestaan; heel/half-overlap toont fout vóór opslaan. SQL-tests controleren de transactie apart.')
add('mapping','F5','uitgevoerd','report.json: agenda-only-changing-no-field + mapping-missing-fields D/M','Een wedstrijd met alleen kleedkamers blijft Nog in te delen. Bronmapping komt niet uit een demo-sync.')
for name in ['agenda-week','agenda-day','agenda-month','agenda-year']:
 add(name,'F0','uitgevoerd','Hoofdarchief: '+name+' D/M; week tevensW/T; jaarT in supplement agenda-year-tablet','Tijd/locale/fixture vast; dezelfde periode19–25okt2026.')
add('agenda-filter-empty','F4','uitgevoerd','report.json: agenda-empty D/M + agenda-filter-empty D/M','Zowel lege activiteitenbron als nul zoekmatches; geen verzonnen activiteiten.')
add('activity-new','F0','uitgevoerd','Hoofdarchief: activiteitmodal D/M + afzonderlijk exact desktopinterieur','Publieke keuze is expliciet; gewone opslag verandert live niet.')
add('activity-source','F0','uitgevoerd','report.json: activity-source D/M','Titel/status/datum/tijd/bronlocaties locked; lokale annotaties en extra koppelingen blijven bewerkbaar.')
for name in ['select-empty-open','select-search','select-no-results']:
 add(name,'F6','uitgevoerd','Hoofdarchief D/M + picker-boundaries/report.json: accent-search/no-results D/M','60opties, accentloze meerwoordmatch, Enter zonder opslaan en eersteEscape houdt modal open.')
for name in ['select-many','select-bottom']:
 add(name,'F6','uitgevoerd','picker-boundaries/report.json: many-chips/bottom-open D/M','Popup blijft binnen de scrollende modal; chipsmax130px; verdwenen selectie verwijderbaar.')
add('select-disabled','F8','uitgevoerd','picker-boundaries/report.json: disabled-option D/M; report.json F8-readonly + F8-scoped D/M','Echte providerprincipal voor readonly/teambeperking; disabled optie verandert selectie niet. Teamcreatiebug gevonden en gerepareerd.')
add('training-week','F0','uitgevoerd','Hoofdarchief D/M en algemene modulebreedtes D/W/T/M','Teamfilter en concrete centrale momenten; geen vrij tekstrooster als nieuwe bron.')
add('training-create','F0','uitgevoerd','Hoofdarchief D/M; supplement training-create-publish-optin + training-publication-optin D/M','Expliciet label “Deze reeks meteen publiceren in de openbare clubagenda”; server publiceert alleen bij afzonderlijke opt-in en rechten.')
add('training-conflict','F3','uitgevoerd','report.json: training-conflict D/M','Conflict fout en onbruikbare preview zichtbaar; geen apply in deze visuele run. Atomair weigeren is apart op echte SQL getest.')
add('training-delete','F0','uitgevoerd','report.json: training-delete-one/training-delete-series D/M','Geen delete in captureharness. Productietekst noemt prullenbak/historie; dit voegt19.797px toe t.o.v. het prototype. Echte53-momenten-delete is in SQL en duurzame E2E gecontroleerd.')
add('public-agenda','F0','uitgevoerd','public-report.json: public-agenda/public-agenda-empty/public-agenda-withdrawn D/M, panelcrops','Alleenpublic+planned, max5, echte plaats/tijdbereik, geen personen/contact. Mobiele lege kaart480px zoals bron; gevulde kaart24.516px compacter door verwijderde bron/demo-badges.')
add('public-agenda-detail','F0','uitgevoerd','public-report.json: public-agenda-detail D/M, werkelijke server-ICSdownload en focus404-intrekking','Detailgeometrie exact gelijk:560×441.969 desktop,358×457.906 mobiel. Intrekken sluit open detail via canonical servercheck.')
for name in ['slider-editor','slider-crop','slider-add','slider-save-states','slider-empty']:
 add(name,'F7/F9','uitgevoerd','Bestaand design/club-planning-2026-10-20/hero-slider/manifest.json + ops/hero-slider-review.md','Eigen F08bewijs:47 gecontroleerde editorpaneelvergelijkingen, alle0RGB. Deze supplementrun telt die niet dubbel.')
add('hero-still','F7','niet uitgevoerd','Zie afzonderlijk F08runtimeverslag; geen aanvullende publieke source/candidate-still in deze supplementrun','De bestaande runtime/motion/geometriechecks zijn wel uitgevoerd door F08; deze status claimt geen ontbrekende deterministische publieke pixelvergelijking.')
add('production-regressions','Productie','uitgevoerd','Hoofdarchief production-before, actuele componentharness, bestaande CI/E2E; supplement15 oudeproductie-headerbeelden D/M','Vergelijking met eigen productie618321b; oudere Sites-editor/nav worden niet teruggezet.')
add('activity-external-conflict','F9','uitgevoerd','report.json: activity-external-conflict D/M','Werkelijke componentprovider met één geïsoleerde409API-response. Bewaarde titel én zichtbare conflictmelding gecontroleerd; geen opslag.')
add('person-import-demo','F1','n.v.t.','F1-identity CSVreview en backendbronadaptertests','Expliciete productie-eis verbiedt import van prototype-demopersonen. Gelijke reviewfunctie is met stabiele fictieve leden-ID’s getest; er is geen echte ledenbron beschikbaar.')
add('source-permission-principal','F8','n.v.t.','Current actual-provider readonly/team-scope D/M','Het lokale prototype heeft geen actiegebonden serverprincipal zoals productie. Een verzonnen bronaccount zou geen geldige exacte rechtenreferentie zijn.')
add('live-Sportlink-members','Extern','niet uitgevoerd','ops/sportlink.md + ops/club-planning-review.md','Geen echte clubcredential in devsessie; geen echte ledenimport, sync of externe berichten tijdens visuele checks.')
json.dump({'reference':'05-VISUELE-ACCEPTATIE.md','statuses':['uitgevoerd','n.v.t.','niet uitgevoerd'],'rows':rows},open(out+'/matrix-status.json','w'),indent=2,ensure_ascii=False)
for file in ['planning-supplement-capture.mjs','planning-public-supplement.mjs','planning-supplement-picker.mjs','planning-supplement-diff.mjs','planning-supplement-matrix.py']:
 shutil.copyfile('.runtime/'+file,out+'/'+file)
json.dump({'files':[{'path':name,'sha256':hashlib.sha256(open(out+'/'+name,'rb').read()).hexdigest()} for name in os.listdir(out) if name.endswith('.json') or name.endswith('.mjs')]},open(out+'/supplement-files.json','w'),indent=2)
print('matrix rows',len(rows))
