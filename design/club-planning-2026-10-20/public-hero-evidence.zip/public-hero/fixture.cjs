var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// lib/cms/club-pages.json
var club_pages_default = {
  club: {
    title: "Onze club",
    coverSrc: "/assets/club-life-v28/supporters-1280.webp",
    intro: "Een plek om te voetballen, elkaar te ontmoeten en samen iets op te bouwen. Ontdek de mensen, de verhalen en alles wat je wilt weten over Duindorp SV.",
    body: {
      type: "doc",
      content: [
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Samen houden we de club draaiende."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Een aanspreekpunt voor elke vraag. Maak kennis met de mensen achter de vereniging."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Het bestuur",
              text: "De mensen en verantwoordelijkheden achter de koers van onze vereniging.",
              url: "/clubmuur/club/bestuur",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Onze commissies",
              text: "Van voetbalzaken tot de kantine. Ontdek wie zich waarvoor inzet.",
              url: "/clubmuur/club/commissies",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Voor onze jeugd",
              text: "Jeugdbestuur, begeleiding en het juiste aanspreekpunt voor spelers en ouders.",
              url: "/clubmuur/club/jeugdorganisatie",
              label: "Lees meer"
            }
          }
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Geworteld in de wijk."
            },
            {
              type: "hardBreak"
            },
            {
              type: "text",
              text: "Trots op onze club."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Van die eerste bal tot de gesprekken langs de lijn. Ons clubgevoel gaat verder dan negentig minuten."
            }
          ]
        },
        {
          type: "image",
          attrs: {
            src: "/assets/club-life-v28/canteen-1280.webp",
            alt: "vrijwilligers in een clubkantine"
          }
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Alles voor jouw clubleven."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Lidmaatschap",
              text: "Lid worden, contributie, kleding en wijzigingen in je lidmaatschap.",
              url: "/clubmuur/club/lidmaatschap",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Op bezoek",
              text: "De route naar Houtrust, onze accommodatie en praktische bezoekersinformatie.",
              url: "/clubmuur/club/accommodatie",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Jouw uurtje telt",
              text: "Vind een taak die bij je past en ontdek hoe jij mee kunt helpen.",
              url: "/clubmuur/club/vrijwilligers",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Zo doen wij dat",
              text: "Sportiviteit, respect en een fijne plek voor iedereen op en rond het veld.",
              url: "/clubmuur/club/clubwaarden",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Clubdocumenten",
              text: "Een overzichtelijke plek voor afspraken, reglementen en clubinformatie.",
              url: "/clubmuur/club/documenten",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Kom in contact",
              text: "Stel je vraag aan het juiste onderdeel van de vereniging.",
              url: "/clubmuur/club/contact",
              label: "Lees meer"
            }
          }
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Een veilige club maken we samen."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Zit je ergens mee? Op de pagina van de vertrouwenspersoon lees je waar je terechtkunt en hoe we dit aanspreekpunt zichtbaar maken."
            }
          ]
        }
      ]
    }
  },
  "club/commissies": {
    title: "Onze commissies",
    intro: "Op het veld, in het clubhuis en achter de schermen. Samen zorgen we dat de vereniging blijft draaien.",
    body: {
      type: "doc",
      content: [
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Onze commissies houden de club draaiende. Hieronder vind je de contactpersonen en hun taken."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "people",
            data: {
              layout: "Commissies"
            }
          }
        }
      ]
    }
  },
  "club/vertrouwenspersoon": {
    title: "Vertrouwenspersoon",
    intro: "Iedereen moet zich prettig kunnen voelen bij de club. Soms wil je iets bespreken met iemand buiten je eigen team.",
    body: {
      type: "doc",
      content: [
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Er mag ruimte zijn"
            },
            {
              type: "hardBreak"
            },
            {
              type: "text",
              text: "voor jouw verhaal."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Voel je je niet prettig door het gedrag van iemand binnen de vereniging? Of twijfel je of iets wel in orde is? Deze pagina helpt je het juiste aanspreekpunt te vinden."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Je hoeft hier geen namen, details of gevoelige informatie achter te laten. Bespreek eerst met het aanspreekpunt hoe een gesprek kan plaatsvinden en wat er met je informatie gebeurt."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Monique Bruijn"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Vertrouwenspersoon Duindorp SV"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Wil je iets bespreken? Neem rechtstreeks contact op en spreek samen een geschikt moment af voor je gesprek."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Bekijk de offici\xEBle contactvermelding ",
              marks: [
                {
                  type: "link",
                  attrs: {
                    href: "/clubmuur/club/vertrouwenspersoon"
                  }
                }
              ]
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Als iets niet goed voelt."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Een vraag of twijfel."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Je wilt iets bespreken, maar weet nog niet precies met wie of hoe."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Gedrag dat raakt."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Bijvoorbeeld pesten, uitsluiten of ander gedrag waardoor je je niet prettig voelt."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Een volgende stap."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Je zoekt iemand die met je meedenkt over een passend aanspreekpunt."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Goed om vooraf te weten."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Moet ik hier vertellen wat er is gebeurd?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Nee. Deze pagina vraagt niet om jouw verhaal of persoonsgegevens. Neem eerst rechtstreeks contact op met de vertrouwenspersoon en bespreek hoe je veilig verder kunt praten."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Is mijn gesprek altijd geheim?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Vraag bij het begin van je gesprek hoe met jouw informatie wordt omgegaan. Spreek samen af wat vertrouwelijk blijft en in welke situaties informatie mogelijk gedeeld moet worden."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Ik heb een gewone vraag over mijn team. Waar moet ik zijn?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Voor teamzaken kun je bij je trainer of teamleider beginnen. Je vindt meer informatie op de "
            },
            {
              type: "text",
              text: "teampagina",
              marks: [
                {
                  type: "link",
                  attrs: {
                    href: "/clubmuur/teams"
                  }
                }
              ]
            },
            {
              type: "text",
              text: " of in de "
            },
            {
              type: "text",
              text: "jeugdwegwijzer",
              marks: [
                {
                  type: "link",
                  attrs: {
                    href: "/clubmuur/club/jeugdorganisatie"
                  }
                }
              ]
            },
            {
              type: "text",
              text: "."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Zo gaan we met elkaar om",
              text: "Bekijk de beschikbare clubafspraken en verenigingsdocumenten.",
              url: "/clubmuur/club/documenten",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Vind je aanspreekpunt",
              text: "De algemene contactroutes van Duindorp SV op \xE9\xE9n plek.",
              url: "/clubmuur/club/contact",
              label: "Lees meer"
            }
          }
        }
      ]
    }
  },
  "club/accommodatie": {
    title: "Accommodatie & route",
    coverSrc: "/assets/clubmuur-brush-v25/houtrust-wide-1280.webp",
    intro: "De weg naar de club. En alles wat je wilt weten voordat je langskomt.",
    body: {
      type: "doc",
      content: [
        {
          type: "image",
          attrs: {
            src: "/assets/clubmuur-brush-v25/section-houtrust-1600.webp",
            alt: "Het clubgebouw van Duindorp SV in onze blauw-witte brushstijl"
          }
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Hier voelen"
            },
            {
              type: "hardBreak"
            },
            {
              type: "text",
              text: "we ons thuis."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Duindorp SV"
            },
            {
              type: "hardBreak"
            },
            {
              type: "text",
              text: "Houtrustlaan 1"
            },
            {
              type: "hardBreak"
            },
            {
              type: "text",
              text: "2566 ZW Den Haag"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Kom je voor een wedstrijd? Controleer de aanvangstijd en locatie in het wedstrijdcentrum."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Een fijne dag op Houtrust."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Een paar praktische handvatten voor spelers, bezoekers en gasten."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "De route naar ons."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "De routeknop opent de locatie in Google Maps. Kies daar zelf voor lopen, fietsen, openbaar vervoer of de auto."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Even wegwijs."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Ben je voor het eerst op de club? Vraag je trainer, teamleider of een vrijwilliger waar je wordt verwacht."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Bijzondere vraag?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Over toegankelijkheid, faciliteiten of een bezoek met een groep? Stem je bezoek vooraf met de club af."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Op het sportpark."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Waar speelt mijn team?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Bekijk eerst het wedstrijdcentrum. Daar staat de beschikbare wedstrijdinformatie uit Sportlink. De definitieve veld- en kleedkamerindeling controleer je op de wedstrijddag bij de club. Een actuele plattegrond is nog niet aan de website toegevoegd."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Gebruik van het kunstgras"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Volg de aangegeven instructies bij het veld. Houd het speelveld vrij van afval en laat materialen netjes achter. Over schoeisel of specifieke afspraken? Vraag het aan je trainer of de beheerder. De offici\xEBle kunstgrasregels komen bij de clubdocumenten."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Kantine en bezoekmomenten"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "De kantine is een ontmoetingsplek voor onze club. Vraag bij een gepland bezoek naar de actuele openingstijden; die zijn nog niet in de website opgenomen."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Iets gevonden of iets kapot?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Spreek een aanwezige vrijwilliger aan of stel je vraag via accommodatiezaken. Beschrijf duidelijk waar je iets hebt gevonden of gezien. Deel geen persoonsgegevens van anderen in een openbare melding."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Het wedstrijdcentrum",
              text: "Programma, uitslagen en wedstrijdinformatie.",
              url: "/clubmuur/wedstrijden",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Trainingen",
              text: "Vind je team en de informatie over trainen.",
              url: "/clubmuur/teams/trainingen",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Clubdocumenten",
              text: "De afspraken over onze club en ons sportpark.",
              url: "/clubmuur/club/documenten",
              label: "Lees meer"
            }
          }
        }
      ]
    }
  },
  "club/lidmaatschap": {
    title: "Lidmaatschap & kleding",
    coverSrc: "/assets/clubmuur-brush-v25/de-wijk-wide-1280.webp",
    intro: "Voor de eerste training, je volgende seizoen en alles daaromheen.",
    body: {
      type: "doc",
      content: [
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Begin met"
            },
            {
              type: "hardBreak"
            },
            {
              type: "text",
              text: "kennismaken."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Een team waarin je je thuis voelt. Mensen die je leren kennen. En samen plezier maken op het veld. Daar begint het."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Of je nu voor het eerst voetbalt of al jaren speelt: laat weten wie je bent en waar je naar zoekt. De club helpt je verder naar een passende plek."
            }
          ]
        },
        {
          type: "image",
          attrs: {
            src: "/assets/club-life-v28/youth-1280.webp",
            alt: "jeugdspelers die samen trainen"
          }
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Wat wil je weten?"
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Van kennismaken naar meedoen."
            }
          ]
        },
        {
          type: "orderedList",
          content: [
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [
                    {
                      type: "text",
                      text: "01"
                    },
                    {
                      type: "text",
                      text: "Vertel iets over jezelf",
                      marks: [
                        {
                          type: "bold"
                        }
                      ]
                    },
                    {
                      type: "text",
                      text: "Geef je leeftijdscategorie, voetbalervaring en voorkeur door aan de ledenadministratie."
                    }
                  ]
                }
              ]
            },
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [
                    {
                      type: "text",
                      text: "02"
                    },
                    {
                      type: "text",
                      text: "Vind een passende plek",
                      marks: [
                        {
                          type: "bold"
                        }
                      ]
                    },
                    {
                      type: "text",
                      text: "De club bekijkt met je bij welk team of welke vorm van voetbal je kunt aansluiten."
                    }
                  ]
                }
              ]
            },
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [
                    {
                      type: "text",
                      text: "03"
                    },
                    {
                      type: "text",
                      text: "Maak samen de afspraken",
                      marks: [
                        {
                          type: "bold"
                        }
                      ]
                    },
                    {
                      type: "text",
                      text: "Bespreek een kennismaking en ontvang de actuele informatie over inschrijven en lidmaatschap."
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3,
            anchor: "contributie"
          },
          content: [
            {
              type: "text",
              text: "Contributie"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "De contributie en eventuele bijkomende kosten horen bij de informatie die je bij je aanmelding ontvangt. Vraag welke afspraken voor jouw leeftijdscategorie of team gelden."
            }
          ]
        },
        {
          type: "table",
          content: [
            {
              type: "tableRow",
              content: [
                {
                  type: "tableHeader",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "Categorie"
                        }
                      ]
                    }
                  ]
                },
                {
                  type: "tableHeader",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "Bedrag"
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            {
              type: "tableRow",
              content: [
                {
                  type: "tableHeader",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "Mini\u2019s"
                        }
                      ]
                    }
                  ]
                },
                {
                  type: "tableCell",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "\u20AC 50"
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            {
              type: "tableRow",
              content: [
                {
                  type: "tableHeader",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "Jeugd t/m O12"
                        }
                      ]
                    }
                  ]
                },
                {
                  type: "tableCell",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "\u20AC 150"
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            {
              type: "tableRow",
              content: [
                {
                  type: "tableHeader",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "Jeugd O13 t/m O19"
                        }
                      ]
                    }
                  ]
                },
                {
                  type: "tableCell",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "\u20AC 185"
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            {
              type: "tableRow",
              content: [
                {
                  type: "tableHeader",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "Senioren"
                        }
                      ]
                    }
                  ]
                },
                {
                  type: "tableCell",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "\u20AC 300"
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            {
              type: "tableRow",
              content: [
                {
                  type: "tableHeader",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "Niet-spelende leden"
                        }
                      ]
                    }
                  ]
                },
                {
                  type: "tableCell",
                  content: [
                    {
                      type: "paragraph",
                      content: [
                        {
                          type: "text",
                          text: "\u20AC 80"
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Contributie per leeftijdscategorie. Voor O13 t/m O19 geldt \u20AC 185 vanaf seizoen 2026/2027. "
            },
            {
              type: "text",
              text: "Informatie over lidmaatschap ",
              marks: [
                {
                  type: "link",
                  attrs: {
                    href: "/clubmuur/club/lidmaatschap#contributie"
                  }
                }
              ]
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Wat kost een lidmaatschap?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "De bovenstaande tabel toont de gepubliceerde contributie per categorie. De vereniging werkt met NIKKI voor de inning. Vraag de ledenadministratie wat inbegrepen is en of er aparte afspraken gelden voor kleding of andere kosten."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Een vraag over betalen?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Neem contact op met de ledenadministratie en bespreek je vraag persoonlijk. Deel geen betaal- of bankgegevens via het contactformulier."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3,
            anchor: "kleding"
          },
          content: [
            {
              type: "text",
              text: "Clubkleding"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Het blauw en wit verbindt ons. Voor de jeugd vermeldt de club voor 2026/2027: wedstrijdshirt \u20AC 45, broek \u20AC 15 en sokken \u20AC 12,50. Vraag je trainer of leider eerst naar de afspraken voor jouw team en eventuele sponsoring."
            }
          ]
        },
        {
          type: "bulletList",
          content: [
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [
                    {
                      type: "text",
                      text: "Welke kleding wordt via het team verstrekt?"
                    }
                  ]
                }
              ]
            },
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [
                    {
                      type: "text",
                      text: "Wat bestel je zelf en via welk kanaal?"
                    }
                  ]
                }
              ]
            },
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [
                    {
                      type: "text",
                      text: "Welke maten en afspraken gelden er?"
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          type: "image",
          attrs: {
            src: "/assets/crest-close.webp",
            alt: "Het Duindorp SV-embleem op het clubshirt"
          }
        },
        {
          type: "heading",
          attrs: {
            level: 3,
            anchor: "wijzigen"
          },
          content: [
            {
              type: "text",
              text: "Wijzigen & opzeggen"
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Mijn contactgegevens zijn veranderd"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Geef wijzigingen door aan de ledenadministratie via de daarvoor afgesproken clubroute. Denk aan een nieuw e-mailadres of telefoonnummer, zodat belangrijke clubinformatie je blijft bereiken."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Ik wil mijn lidmaatschap opzeggen"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "De club vraagt om een schriftelijke opzegging; per e-mail is voldoende. Bekijk de "
            },
            {
              type: "text",
              text: "offici\xEBle opzegpagina",
              marks: [
                {
                  type: "link",
                  attrs: {
                    href: "/clubmuur/club/contact?onderwerp=lidmaatschap"
                  }
                }
              ]
            },
            {
              type: "text",
              text: " voor de juiste contactroute en vraag om een bevestiging. Een opzegtermijn is hier niet bevestigd. Vermeld je naam en team en vraag het secretariaat om een ontvangstbevestiging."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Ik wil van team of vorm van voetbal veranderen"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Bespreek je wens eerst met de team- of jeugdco\xF6rdinatie. Samen kun je kijken wat mogelijk is en welke administratieve stappen daarbij horen."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "form",
            data: {
              refId: "membership"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Ontdek onze teams",
              text: "Van de eerste stappen tot een leven lang voetbal.",
              url: "/clubmuur/teams",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Meedoen kan ook anders",
              text: "Ook naast het veld is er een plek voor jou.",
              url: "/clubmuur/club/vrijwilligers",
              label: "Lees meer"
            }
          }
        }
      ]
    }
  },
  "club/clubwaarden": {
    title: "Clubwaarden",
    coverSrc: "/assets/clubmuur-brush-v25/de-wijk-wide-1280.webp",
    intro: "Met plezier in het spel, respect voor elkaar en een Duindorps hart.",
    body: {
      type: "doc",
      content: [
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Trots zijn doen we samen."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Voor elkaar."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "We zien elkaar staan. Nieuwe gezichten krijgen een welkom en iedereen verdient een plek om met plezier mee te doen."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Voor het spel."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "We gaan voor onze kleuren, spelen sportief en behandelen tegenstanders, scheidsrechters en vrijwilligers met respect."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Voor Duindorp."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "We zorgen voor onze club en onze omgeving. Op Houtrust, op bezoek bij een andere vereniging en daarbuiten."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Moedig aan."
            },
            {
              type: "hardBreak"
            },
            {
              type: "text",
              text: "Geef plezier door.",
              marks: [
                {
                  type: "bold"
                }
              ]
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Zo maken we het concreet."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Op het veld en langs de lijn"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Steun je team op een positieve manier. Geef spelers de ruimte om te leren en accepteer dat iedereen fouten maakt. Bespreek een verschil van mening rustig en via de juiste persoon."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "In de kleedkamer en kantine"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Behandel elkaar en de materialen met zorg. Laat je plek netjes achter en help een ander als dat nodig is. Onze vrijwilligers maken de club mogelijk; geef ze de waardering die daarbij hoort."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Online en op sociale media"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Ook online draag je bij aan de sfeer rond onze club. Reageer respectvol, denk na voordat je iets deelt en houd rekening met de privacy en wensen van anderen."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Wanneer iets niet goed voelt"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Blijf er niet alleen mee lopen. Bekijk de pagina "
            },
            {
              type: "text",
              text: "Vertrouwenscontactpersoon",
              marks: [
                {
                  type: "link",
                  attrs: {
                    href: "/clubmuur/club/vertrouwenspersoon"
                  }
                }
              ]
            },
            {
              type: "text",
              text: " voor persoonlijk contact. Een gevoelige kwestie hoort in een persoonlijk gesprek, niet in een openbare reactie of het contactformulier."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "De mensen achter de club",
              text: "Vind bestuur, commissies en de juiste aanspreekpunten.",
              url: "/clubmuur/club/bestuur",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Afspraken op papier",
              text: "Bekijk welke offici\xEBle clubdocumenten beschikbaar komen.",
              url: "/clubmuur/club/documenten",
              label: "Lees meer"
            }
          }
        }
      ]
    }
  },
  "club/documenten": {
    title: "Clubdocumenten",
    intro: "De afspraken en informatie van onze vereniging op \xE9\xE9n overzichtelijke plek.",
    body: {
      type: "doc",
      content: [
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Hier vind je de gepubliceerde documenten van onze vereniging."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "documents",
            data: {}
          }
        }
      ]
    }
  },
  "club/contact": {
    title: "Contact",
    coverSrc: "/assets/clubmuur-brush-v25/houtrust-wide-1280.webp",
    intro: "Een vraag, een idee of gewoon even kennismaken? Begin bij het juiste onderwerp.",
    body: {
      type: "doc",
      content: [
        {
          type: "cmsWidget",
          attrs: {
            kind: "form",
            data: {
              refId: "contact"
            }
          }
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Tot op Houtrust."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Duindorp SV"
            },
            {
              type: "hardBreak"
            },
            {
              type: "text",
              text: "Houtrustlaan 1"
            },
            {
              type: "hardBreak"
            },
            {
              type: "text",
              text: "2566 ZW Den Haag"
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Wie doet wat?",
              text: "Maak kennis met het bestuur.",
              url: "/clubmuur/club/bestuur",
              label: "Lees meer"
            }
          }
        }
      ]
    }
  },
  "teams/trainingen": {
    title: "Trainingstijden",
    coverSrc: "/assets/clubmuur-brush-v25/section-houtrust-1600.webp",
    intro: "Van die eerste bal tot een perfecte pass. Op het trainingsveld begint de volgende mooie zaterdag.",
    body: {
      type: "doc",
      content: [
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Op naar het veld."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Vind het trainingsmoment van je team en zie op welk veld je wordt verwacht. Je trainer of teamleider deelt eventuele wijzigingen."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Jouw week begint hier."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Het onderstaande rooster komt van de offici\xEBle clubwebsite, gecontroleerd op 10 oktober 2026. Bij vakanties, slecht weer of een wijziging hoor je de actuele afspraken van je teambegeleiding."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "training",
            data: {}
          }
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Kan ik eerst een keer meetrainen?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Leuk dat je wilt kennismaken. Neem vooraf contact op met de club. De co\xF6rdinator kijkt welke groep bij je past en stemt een kennismaking af met de trainer. "
            },
            {
              type: "text",
              text: "Vraag naar meetrainen.",
              marks: [
                {
                  type: "link",
                  attrs: {
                    href: "/clubmuur/club/contact?onderwerp=meetrainen"
                  }
                }
              ]
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Waar vind ik wijzigingen of afgelastingen?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Je trainer of teamleider deelt wijzigingen in de teamcommunicatie. Wedstrijdinformatie staat in het "
            },
            {
              type: "text",
              text: "wedstrijdcentrum",
              marks: [
                {
                  type: "link",
                  attrs: {
                    href: "/clubmuur/wedstrijden"
                  }
                }
              ]
            },
            {
              type: "text",
              text: ". Een afgelaste wedstrijd betekent niet automatisch dat een training ook vervalt."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Wat neem ik mee naar een training?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Neem sportkleding voor het weer, geschikte voetbalschoenen, scheenbeschermers en een gevulde bidon mee. Stem specifieke afspraken met je trainer af."
            }
          ]
        }
      ]
    }
  },
  "teams/walking-football": {
    title: "Walking Football",
    intro: "Voetbal op wandeltempo. Samen bewegen, een bal trappen en daarna tijd voor elkaar. Je hoeft het spel nooit los te laten.",
    body: {
      type: "doc",
      content: [
        {
          type: "image",
          attrs: {
            src: "/assets/club-life-v28/walking-1280.webp",
            alt: "Sfeerbeeld van senioren die samen voetballen"
          }
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Blijf in beweging. Blijf erbij."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Het gaat om de bal, maar net zo goed om de mensen eromheen. Bij Walking Football is er ruimte voor sportief plezier, een goed gesprek en nieuwe contacten in de wijk."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "We spelen op wandeltempo, zonder rennen. Een laagdrempelige manier om samen actief te zijn en de sfeer van de club te blijven beleven."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Een nieuw begin. Samen."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "De eerste training staat gepland op dinsdag 27 oktober 2026. Wil je aansluiten of eerst even komen kijken? Laat het de club weten."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Op jouw tempo."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Samen actief zijn, met aandacht voor elkaar en ruimte om mee te doen."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Nieuwe contacten."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Ontmoet andere voetballiefhebbers uit de club en uit de wijk."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Het plezier voorop."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "De bal blijft rollen. Ontspanning en samenspel staan centraal."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Een paar snelle antwoorden."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Moet ik al kunnen voetballen?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Voetbalervaring is mooi meegenomen, maar plezier in samen bewegen is het belangrijkste. Bespreek je ervaring en wensen met de begeleiding bij je kennismaking."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Kan ik een keer komen kijken?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Graag. Neem vooraf contact op, dan kunnen we je vertellen wanneer je welkom bent en waar je je kunt melden. "
            },
            {
              type: "text",
              text: "Vraag een kennismaking aan.",
              marks: [
                {
                  type: "link",
                  attrs: {
                    href: "/clubmuur/club/contact?onderwerp=walking-football"
                  }
                }
              ]
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Wat zijn de trainingsmomenten en kosten?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "De eerste training is gepland op 27 oktober 2026. Het exacte tijdstip, het vaste rooster en eventuele kosten worden nog bevestigd. Vraag de vereniging naar de actuele afspraken voordat je langskomt."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Hoe meld ik mijn belangstelling?"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Gebruik de contactpagina en kies Walking Football als onderwerp. Je kunt daar een bericht voorbereiden voor de vereniging. "
            },
            {
              type: "text",
              text: "Naar contact.",
              marks: [
                {
                  type: "link",
                  attrs: {
                    href: "/clubmuur/club/contact?onderwerp=walking-football"
                  }
                }
              ]
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Meer dan een club.",
              text: "Maak kennis met Duindorp SV, onze mensen en onze wijk.",
              url: "/clubmuur/club",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Elke generatie telt.",
              text: "Ontdek alle teams die onze blauw-witte kleuren dragen.",
              url: "/clubmuur/teams",
              label: "Lees meer"
            }
          }
        }
      ]
    }
  },
  "wedstrijden/informatie": {
    title: "Wedstrijdinformatie",
    coverSrc: "/assets/clubmuur-brush-v25/section-houtrust-1600.webp",
    intro: "De aftrap, de route en de afspraken. Hier vind je wat je nodig hebt voor een fijne dag bij Duindorp SV.",
    body: {
      type: "doc",
      content: [
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Programma & uitslagen",
              text: "Zoek je team, de aanvangstijd en de locatie.",
              url: "/clubmuur/wedstrijden",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Afgelastingen",
              text: "Bekijk doorgegeven wijzigingen via Sportlink.",
              url: "/clubmuur/wedstrijden/afgelastingen",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Op bezoek bij ons",
              text: "Route, accommodatie en praktische informatie.",
              url: "/clubmuur/club/accommodatie",
              label: "Lees meer"
            }
          }
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Goed voorbereid het veld op."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Een goede wedstrijddag begint met heldere afspraken binnen je team."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Voor vertrek"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Bekijk het actuele programma en stem de verzameltijd, het vervoer en je tenue af met de teambegeleiding. Een aanvangstijd kan nog wijzigen."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Op het sportpark"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Vraag je begeleider naar de kleedkamer en het veld. Houd doorgangen vrij en laat de kleedkamer samen netjes achter."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 3
          },
          content: [
            {
              type: "text",
              text: "Vragen over je wedstrijd"
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Je trainer of teamleider is je eerste aanspreekpunt. Voor een wijziging of organisatorische vraag kun je terecht bij wedstrijdzaken via de contactpagina."
            }
          ]
        },
        {
          type: "heading",
          attrs: {
            level: 2
          },
          content: [
            {
              type: "text",
              text: "Sportief op \xE9n naast het veld."
            }
          ]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Onze clubwaarden geven richting aan hoe we met elkaar omgaan."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Een vraag voor wedstrijdzaken",
              text: "Vind het aanspreekpunt voor jouw wedstrijd.",
              url: "/clubmuur/club/contact?onderwerp=wedstrijdzaken",
              label: "Lees meer"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Veilig sporten",
              text: "Een luisterend oor en de juiste route bij zorgen.",
              url: "/clubmuur/club/vertrouwenspersoon",
              label: "Lees meer"
            }
          }
        }
      ]
    }
  },
  "wedstrijden/afgelastingen": {
    title: "Afgelastingen",
    intro: "Afgelastingen en andere onderbrekingen uit het beschikbare Sportlink-programma, voor alle teams op \xE9\xE9n plek.",
    body: {
      type: "doc",
      content: [
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "Hieronder vind je de actuele afgelastingen. Je trainer of teamleider deelt eventuele wijzigingen van trainingen en teamafspraken."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "matches",
            data: {
              layout: "cancellations"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Programma en uitslagen",
              label: "Naar het wedstrijdcentrum",
              url: "/clubmuur/wedstrijden"
            }
          }
        }
      ]
    }
  },
  "wedstrijden/oefenwedstrijd": {
    title: "Oefenwedstrijd aanvragen",
    intro: "Stuur je voorstel voor een oefenwedstrijd naar de club. Een wedstrijd is definitief zodra beide verenigingen de afspraken hebben bevestigd.",
    body: {
      type: "doc",
      content: [
        {
          type: "cmsWidget",
          attrs: {
            kind: "form",
            data: {
              refId: "friendly-request"
            }
          }
        }
      ]
    }
  },
  "media/club-tv": {
    title: "Duindorp SV-TV",
    intro: "Van een mooi doelpunt tot een goed gesprek langs de lijn. Een plek voor de verhalen van onze vereniging in bewegend beeld.",
    body: {
      type: "doc",
      content: [
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "De verhalen en beelden van Duindorp SV. Ontdek het laatste clubnieuws en de momenten in onze fotoalbums."
            }
          ]
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "Het laatste nieuws",
              label: "Lees het clubnieuws",
              url: "/clubmuur/nieuws"
            }
          }
        },
        {
          type: "cmsWidget",
          attrs: {
            kind: "cta",
            data: {
              title: "De fotomuur",
              label: "Bekijk de albums",
              url: "/clubmuur/media/fotos"
            }
          }
        }
      ]
    }
  },
  "media/nieuwsbrief": {
    title: "Nieuwsbrief",
    intro: "Vraag de clubnieuwsbrief aan en bevestig je toestemming via e-mail.",
    body: {
      type: "doc",
      content: [
        {
          type: "cmsWidget",
          attrs: {
            kind: "newsletter",
            data: {}
          }
        }
      ]
    }
  }
};

// lib/cms/layout/document.ts
var richTypes = /* @__PURE__ */ new Set(["doc", "paragraph", "heading", "text", "bulletList", "orderedList", "listItem", "blockquote", "hardBreak", "horizontalRule", "image", "table", "tableRow", "tableCell", "tableHeader", "codeBlock", "taskList", "taskItem"]);
var marks = /* @__PURE__ */ new Set(["bold", "italic", "underline", "strike", "code", "link", "highlight", "subscript", "superscript"]);
var widgetKinds = /* @__PURE__ */ new Set(["person", "people", "image", "textImage", "album", "news", "story", "documents", "faq", "timeline", "cta", "team", "contact", "form", "training", "newsletter", "matches"]);
var presets = { layout: ["full", "equal", "wide-left", "wide-right"], gap: ["small", "normal", "large"], padding: ["none", "small", "normal", "large"], tone: ["default", "soft", "blue"], verticalAlign: ["start", "center", "end"] };
function safeDestination(value) {
  return typeof value === "string" && (!value || /^(https?:\/\/|mailto:|tel:|\/(?!\/)|#)/i.test(value) && !/[\u0000-\u0020\\]/.test(value));
}
function nodeId(n) {
  return String(n.attrs?.id || n.type || "document");
}
function validateDocument(doc, format = "page-layout-v2") {
  const issues = [];
  const seen = /* @__PURE__ */ new Set();
  let count = 0;
  const add = (n, message) => issues.push({ nodeId: nodeId(n), message });
  if (JSON.stringify(doc).length > 1e6) return [{ nodeId: "document", message: "Document is groter dan 1 MB." }];
  function visit(n, parent, depth, legacy = false) {
    if (++count > 5e3 || depth > 30) {
      add(n, "Document is te groot of te diep.");
      return;
    }
    if (!n || typeof n.type !== "string") {
      add(n || {}, "Node mist een type.");
      return;
    }
    const structural = ["cmsRow", "cmsColumn", "cmsRichText", "cmsWidget", "cmsLegacyRichText"].includes(n.type);
    if (structural && format === "page-layout-v2" && !legacy) {
      const id = n.attrs?.id;
      if (typeof id !== "string" || !id || seen.has(id)) add(n, "Structurele ID ontbreekt of is dubbel.");
      else seen.add(id);
    }
    if (n.type === "doc") {
      if (parent !== "root") add(n, "Document mag niet genest zijn.");
      if (format === "page-layout-v2" && !legacy && (!n.content?.length || n.content.some((c) => c.type !== "cmsRow"))) add(n, "Pagina vereist minimaal \xE9\xE9n rij en uitsluitend rijen.");
    } else if (n.type === "cmsRow") {
      if (parent !== "doc" || legacy || format !== "page-layout-v2") add(n, "Rij staat buiten het document.");
      const cols = n.content || [];
      const layout = n.attrs?.layout;
      if (!cols.length || cols.length > 2 || cols.some((c) => c.type !== "cmsColumn")) add(n, "Rij vereist \xE9\xE9n of twee kolommen.");
      if ((layout === "full" ? 1 : 2) !== cols.length) add(n, "Verhouding en kolomaantal verschillen.");
      for (const [key2, values] of Object.entries(presets)) if (!values.includes(n.attrs?.[key2])) add(n, `Ongeldige preset: ${key2}.`);
    } else if (n.type === "cmsColumn") {
      if (parent !== "cmsRow" || legacy) add(n, "Kolom staat buiten een rij.");
      if (n.content?.some((c) => !["cmsRichText", "cmsWidget", "cmsLegacyRichText"].includes(c.type || ""))) add(n, "Kolom bevat een ongeldige widget.");
    } else if (n.type === "cmsRichText") {
      if (parent !== "cmsColumn" || legacy) add(n, "Tekstwidget staat buiten een kolom.");
      if (!n.content?.length) add(n, "Tekstwidget vereist een bewerkbare alinea.");
    } else if (n.type === "cmsLegacyRichText") {
      if (parent !== "cmsColumn" || !n.attrs?.sourceDoc) add(n, "Ongeldige compatibiliteitswidget.");
      if (n.content?.length) add(n, "Compatibiliteitswidget is atomair.");
      if (n.attrs?.sourceDoc) visit(n.attrs.sourceDoc, "root", depth + 1, true);
    } else if (n.type === "cmsWidget") {
      if (format === "article" || format === "page-layout-v2" && !legacy && parent !== "cmsColumn") add(n, "Widget staat buiten een kolom.");
      if (n.content?.length) add(n, "Inhoudswidget is atomair.");
      const kind = n.attrs?.kind, d = n.attrs?.data;
      if (!widgetKinds.has(kind) && !(kind === "columns" && (legacy || format === "legacy-tiptap-v1"))) add(n, "Onbekende widgetsoort.");
      if (!d || typeof d !== "object" || Array.isArray(d)) {
        add(n, "Widgetinstellingen ontbreken.");
        return;
      }
      const allowed = ["title", "text", "refId", "ids", "url", "label", "layout", "items", "contentType", "storyFormat", "teamId", "authorId", "limit", "alt", "caption", "credit", "ratio"];
      for (const [key2, value] of Object.entries(d)) {
        if (!allowed.includes(key2)) add(n, `Onbekende widgetinstelling: ${key2}.`);
        if (typeof value === "string" && value.length > 5e4) add(n, "Widgetinstelling is te lang.");
        if (key2 === "url" && !safeDestination(value)) add(n, "Onveilige link.");
      }
      if (d.contentType && !["news", "story"].includes(d.contentType)) add(n, "Ongeldig inhoudstype.");
      if (format === "page-layout-v2" && !legacy && kind === "news" && d.contentType !== "news") add(n, "Nieuwsselectie vereist expliciet news.");
      if (kind === "story" && d.contentType !== "story") add(n, "Verhalenselectie vereist expliciet story.");
      if (d.ids && (!Array.isArray(d.ids) || d.ids.some((v) => typeof v !== "string"))) add(n, "Ongeldige referenties.");
      if (d.items) {
        if (!Array.isArray(d.items) || d.items.length > 200) add(n, "Ongeldige items.");
        else for (const item of d.items) if (!item || typeof item.title !== "string" || typeof item.text !== "string" || item.url && !safeDestination(item.url)) add(n, "Ongeldig item of onveilige link.");
      }
    } else {
      if (!richTypes.has(n.type)) add(n, `Onbekende tekstnode: ${n.type}.`);
      if (["doc", "cmsColumn", "cmsRow", "cmsWidget", "cmsLegacyRichText"].includes(parent) && format === "page-layout-v2" && !legacy) add(n, "Tekst staat buiten een tekstwidget.");
      if (n.type === "heading" && ![2, 3, 4, 5, 6].includes(n.attrs?.level)) add(n, "Ongeldige kop; paginatitel levert H1.");
      if (n.type === "image" && n.attrs?.src && !safeDestination(n.attrs.src)) add(n, "Onveilige afbeeldingsbron.");
      for (const mark of n.marks || []) {
        if (!marks.has(mark.type)) add(n, "Onbekende tekstopmaak.");
        if (mark.type === "link" && !safeDestination(mark.attrs?.href)) add(n, "Onveilige link.");
      }
    }
    for (const key2 of Object.keys(n.attrs || {})) if (/^(on|style$|html$|class$)/i.test(key2)) add(n, "Vrije HTML of opmaak is niet toegestaan.");
    for (const child of n.content || []) visit(child, n.type, depth + 1, legacy);
  }
  visit(doc, "root", 0);
  return issues;
}
function assertLayout(doc) {
  const errors = validateDocument(doc);
  if (errors.length) throw new Error(errors.map((e) => `${e.nodeId}: ${e.message}`).join("\n"));
  return doc;
}
var freshId = () => `node-${globalThis.crypto.randomUUID()}`;
function rich(content = [{ type: "paragraph" }], id = freshId()) {
  return { type: "cmsRichText", attrs: { id }, content };
}
function column(content = [], id = freshId()) {
  return { type: "cmsColumn", attrs: { id }, content };
}
function row(layout = "full", columns, id = freshId()) {
  return { type: "cmsRow", attrs: { id, layout, gap: "normal", padding: "normal", tone: "default", verticalAlign: "start" }, content: columns || Array.from({ length: layout === "full" ? 1 : 2 }, () => column()) };
}
function deterministicId(key2) {
  let hash = 2166136261;
  for (const c of key2) {
    hash ^= c.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return `migrated-${(hash >>> 0).toString(16)}-${key2.length}`;
}
function migrateLayout(body, key2 = "page") {
  if (body.content?.some((n) => n.type === "cmsRow")) return assertLayout(structuredClone(body));
  const errors = validateDocument(body, "legacy-tiptap-v1");
  if (errors.length) throw new Error(errors.map((e) => e.message).join("; "));
  const rows = [];
  let pending = [];
  let serial = 0;
  const id = () => deterministicId(`${key2}:${serial++}`);
  const makeRow = (content, layout = "full") => row(layout, content, id());
  const hasWidget = (n) => n.type === "cmsWidget" || !!n.content?.some(hasWidget);
  const flush = () => {
    if (!pending.length) return;
    const content = pending;
    pending = [];
    const widget = content.some(hasWidget) ? { type: "cmsLegacyRichText", attrs: { id: id(), sourceDoc: { type: "doc", content: structuredClone(content) } } } : rich(structuredClone(content), id());
    rows.push(makeRow([column([widget], id())]));
  };
  for (const node of body.content || []) {
    if (node.type !== "cmsWidget") {
      pending.push(node);
      continue;
    }
    flush();
    const d = node.attrs?.data || {};
    if (node.attrs?.kind === "columns") {
      if (["text", "refId", "ids", "url", "label", "layout", "contentType"].some((k) => Array.isArray(d[k]) ? d[k].length > 0 : !!d[k])) throw new Error("Onverwachte kolominstellingen; handmatige beoordeling nodig.");
      if (Object.keys(d).some((k) => !["title", "text", "refId", "ids", "url", "label", "layout", "items", "contentType"].includes(k))) throw new Error("Onbekende kolominstellingen; handmatige beoordeling nodig.");
      if (d.title) rows.push(makeRow([column([rich([{ type: "heading", attrs: { level: 2 }, content: [{ type: "text", text: d.title }] }], id())], id())]));
      const items = d.items || [];
      for (let i = 0; i < items.length; i += 2) {
        const chunk = items.slice(i, i + 2);
        const columns = chunk.map((item) => {
          if (Object.keys(item).some((k) => !["title", "text", "url"].includes(k))) throw new Error("Onbekende kolomvelden; handmatige beoordeling nodig.");
          const nodes = [];
          if (item.title) nodes.push({ type: "heading", attrs: { level: 3 }, content: [{ type: "text", text: item.title }] });
          nodes.push({ type: "paragraph", content: item.text ? [{ type: "text", text: item.text }] : [] });
          if (item.url) nodes.push({ type: "paragraph", content: [{ type: "text", text: item.url, marks: [{ type: "link", attrs: { href: item.url } }] }] });
          return column([rich(nodes, id())], id());
        });
        rows.push(makeRow(columns, chunk.length === 2 ? "equal" : "full"));
      }
    } else {
      const copy = structuredClone(node);
      copy.attrs = { ...copy.attrs, id: id() };
      if (copy.attrs.kind === "news") {
        copy.attrs.data.contentType ||= "news";
        if (copy.attrs.data.contentType === "story") copy.attrs.kind = "story";
      }
      rows.push(makeRow([column([copy], id())]));
    }
  }
  flush();
  return assertLayout({ type: "doc", content: rows.length ? rows : [makeRow([column([], id())])] });
}

// lib/cms/form-presets.ts
var field = (id, label, type = "text", required = true, extra = {}) => ({ id, label, type, required, ...extra });
var guardian = { fieldId: "birthDate", operator: "under18" };
var publicFormPresets = [
  { id: "contact", kind: "contact", name: "Contact met de club", departmentId: "secretariaat", active: true, retentionDays: 90, fields: [field("name", "Naam"), field("email", "E-mailadres", "email"), field("message", "Bericht", "textarea")] },
  { id: "membership", kind: "registration", registrationPurpose: "membership", consentVersion: "membership-intake-v1", name: "Inschrijven bij Duindorp SV", departmentId: "secretariaat", active: true, retentionDays: 90, fields: [
    field("firstName", "Voornaam", "text", true, { section: "Persoonlijke gegevens" }),
    field("lastName", "Achternaam", "text", true, { section: "Persoonlijke gegevens" }),
    field("birthDate", "Geboortedatum", "date", true, { section: "Persoonlijke gegevens" }),
    field("email", "E-mailadres", "email", true, { section: "Persoonlijke gegevens" }),
    field("phone", "Telefoonnummer", "tel", true, { section: "Persoonlijke gegevens" }),
    field("street", "Straatnaam", "text", true, { section: "Adres" }),
    field("houseNumber", "Huisnummer en toevoeging", "text", true, { section: "Adres" }),
    field("postalCode", "Postcode", "text", true, { section: "Adres" }),
    field("city", "Woonplaats", "text", true, { section: "Adres" }),
    field("guardianName", "Naam ouder / voogd", "text", true, { section: "Ouder of voogd", condition: guardian }),
    field("guardianEmail", "E-mailadres ouder / voogd", "email", true, { section: "Ouder of voogd", condition: guardian }),
    field("guardianPhone", "Telefoonnummer ouder / voogd", "tel", true, { section: "Ouder of voogd", condition: guardian }),
    field("otherClub", "Ben je op dit moment ingeschreven bij een andere vereniging?", "select", true, { section: "Voetbal en opmerkingen", options: ["Ja", "Nee"] }),
    field("currentClub", "Naam van de vereniging", "text", true, { section: "Voetbal en opmerkingen", condition: { fieldId: "otherClub", operator: "equals", value: "Ja" } }),
    field("knvbCode", "KNVB-relatiecode", "text", false, { section: "Voetbal en opmerkingen" }),
    field("message", "Opmerkingen", "textarea", false, { section: "Voetbal en opmerkingen" })
  ] },
  { id: "sponsorship", kind: "request", name: "Sponsor worden", departmentId: "sponsoring", active: true, retentionDays: 90, fields: [field("name", "Naam contactpersoon"), field("company", "Bedrijfsnaam"), field("email", "E-mailadres", "email"), field("phone", "Telefoonnummer", "tel", false), field("message", "Hoe wil je de club sponsoren?", "textarea")] },
  { id: "friendly-request", kind: "request", name: "Oefenwedstrijd aanvragen", departmentId: "secretariaat", active: true, retentionDays: 90, fields: [field("name", "Naam contactpersoon"), field("email", "E-mailadres", "email"), field("phone", "Telefoonnummer", "tel", false), field("club", "Vereniging"), field("team", "Team"), field("level", "Speelsterkte / klasse", "text", false), field("date", "Gewenste datum", "date"), field("venue", "Voorkeurslocatie", "select", true, { options: ["In overleg", "Bij Duindorp SV", "Bij onze vereniging"] }), field("message", "Extra informatie", "textarea", false)] }
];

// lib/club-data.ts
var articles = [
  { id: "ons-shirt", category: "Clubnieuws", title: "Ons shirt. Onze kleuren. Onze trots.", intro: "Wit en blauw. Een herkenbare V. Een shirt dat vertelt waar we vandaan komen.", image: "/assets/kit-campaign.png", date: "8 oktober 2026", minutes: 3, body: ["Je trekt niet zomaar een shirt aan. Je draagt je club, je teamgenoten en een stukje Duindorp. De blauwe V, de fijne strepen en het vertrouwde embleem brengen dat gevoel bij elkaar.", "Het nieuwe wedstrijdtenue combineert een witte basis met het blauw van onze club. Op de borst staat Zarautz Diner Caf\xE9. Van de kleedkamer tot de laatste minuut: dit zijn onze kleuren."] },
  { id: "samen-langs-de-lijn", category: "Vereniging", title: "Zaterdag begint langs de lijn.", intro: "Koffie in de hand. Bekende gezichten. Een hele dag Duindorp.", image: "/assets/terrace.webp", date: "7 oktober 2026", minutes: 2, body: ["Voor het eerste fluitsignaal is de club al wakker. Vrijwilligers maken de velden klaar, ouders zoeken hun plek langs de lijn en in het clubhuis staat de koffie klaar.", "Dat is de kracht van een vereniging: iedereen doet mee. Spelen, aanmoedigen, rijden, fluiten of een uurtje helpen. Ook de kleine dingen maken een groot verschil."] },
  { id: "voorbeschouwing", category: "Eerste elftal", title: "Alles voor die drie punten.", intro: "Het eerste maakt zich klaar voor een nieuwe zaterdag op Houtrust.", image: "/assets/floodlight.webp", date: "6 oktober 2026", minutes: 4, body: ["De voorbereiding zit erop. Op het trainingsveld is gewerkt aan scherpte, samenspel en het moment waarop iedereen hetzelfde denkt: nu."] },
  { id: "iedereen-doet-mee", category: "Jeugd", title: "Grote dromen beginnen hier.", intro: "Samen beter worden, nieuwe vrienden maken en vooral lekker voetballen.", image: "/assets/crest-close.webp", date: "5 oktober 2026", minutes: 2, body: ["Voor de jongste spelers gaat voetbal om ontdekken. De eerste geslaagde pass, een redding waar je trots op bent en een team dat samen plezier maakt.", "Bij een club hoor je erbij. Trainers en vrijwilligers zorgen ervoor dat ieder kind zich thuis kan voelen, met aandacht voor sportiviteit en ontwikkeling."] },
  { id: "vrijwilligers", category: "Vereniging", title: "De mensen achter de zaterdag.", intro: "Onze club draait op mensen die er gewoon staan. Elke week weer.", image: "/assets/team.png", date: "3 oktober 2026", minutes: 3, body: ["Achter iedere wedstrijd staan mensen die zorgen dat de dag goed begint. De sleutel van het hek, het bord langs het veld, de schone kleedkamer en de warme ontvangst.", "Van jeugdtrainer tot gastheer: je hoeft geen hele dag vrij te maken om iets te betekenen. Samen vinden we een taak die past bij jouw tijd en talent."] },
  { id: "walking-football", category: "Voetbal", title: "Voetbal kent geen eindfluitsignaal.", intro: "Blijven bewegen. Samen een bal trappen. En daarna tijd voor elkaar.", image: "/assets/crest-close.webp", date: "1 oktober 2026", minutes: 2, body: ["De liefde voor voetbal stopt niet bij een bepaalde leeftijd. Walking football draait om bewegen op je eigen tempo, plezier en contact met anderen.", "Een ontspannen spelvorm, dezelfde clubkleuren en na afloop samen napraten. Zo blijft de club een plek voor iedere generatie."] }
];
var teams = [
  { id: "1", name: "Duindorp SV 1", group: "Senioren", tag: "Het eerste", time: "Di & do \xB7 20.00 uur", field: "Veld 1", members: 22, coach: "Technische staf", image: "/assets/team.png", description: "Ambitie op het veld. Duindorp in het hart. Volg ons eerste elftal, van de voorbereiding tot het laatste fluitsignaal." },
  { id: "2", name: "Duindorp SV 2", group: "Senioren", tag: "Zaterdag", time: "Di & do \xB7 19.30 uur", field: "Veld 2", members: 20, coach: "Technische staf", image: "/assets/crest-close.webp", description: "Een hechte groep met plezier in het spel. Samen trainen, samen presteren en samen de zaterdag beleven." },
  { id: "jo19", name: "JO19-1", group: "Jeugd", tag: "De volgende generatie", time: "Ma & wo \xB7 19.30 uur", field: "Veld 2", members: 18, coach: "Jeugdopleiding", image: "/assets/kit-campaign.png", description: "De laatste stap in de jeugd. Werken aan techniek, verantwoordelijkheid en het spel als team." },
  { id: "jo15", name: "JO15-1", group: "Jeugd", tag: "Vol energie", time: "Ma & wo \xB7 18.00 uur", field: "Veld 2", members: 16, coach: "Jeugdopleiding", image: "/assets/crest-close.webp", description: "Samen leren en groeien. Elke training een beetje beter, elke wedstrijd een nieuw avontuur." },
  { id: "mo17", name: "MO17-1", group: "Meiden", tag: "Samen vooruit", time: "Di & do \xB7 18.30 uur", field: "Veld 2", members: 17, coach: "Jeugdopleiding", image: "/assets/kit-campaign.png", description: "Een eigen team, dezelfde clubtrots. Meidenvoetbal vol plezier, energie en ontwikkeling." },
  { id: "walking", name: "Walking football", group: "Walking football", tag: "Altijd blijven spelen", time: "Dinsdag \xB7 10.00 uur", field: "Veld 1", members: 14, coach: "Begeleiding walking football", image: "/assets/crest-close.webp", description: "Voetbal op je eigen tempo. In beweging blijven, elkaar ontmoeten en samen genieten van het spel." }
];

// lib/clubmuur-page-routes.ts
var clubContentPaths = [
  "club",
  "club/ons-verhaal",
  "club/bestuur",
  "club/commissies",
  "club/jeugdorganisatie",
  "club/vertrouwenspersoon",
  "club/accommodatie",
  "club/lidmaatschap",
  "club/vrijwilligers",
  "club/clubwaarden",
  "club/documenten",
  "club/contact",
  "teams/trainingen",
  "teams/walking-football",
  "wedstrijden/informatie",
  "wedstrijden/afgelastingen",
  "wedstrijden/oefenwedstrijd",
  "media/fotos",
  "media/club-tv",
  "media/nieuwsbrief"
];
var paths = new Set(clubContentPaths);
var clubContentTitles = {
  "club": "Onze club",
  "club/ons-verhaal": "Ons verhaal",
  "club/bestuur": "Het bestuur",
  "club/commissies": "Onze commissies",
  "club/jeugdorganisatie": "Jeugdorganisatie",
  "club/vertrouwenspersoon": "Vertrouwenspersoon",
  "club/accommodatie": "Accommodatie & route",
  "club/lidmaatschap": "Lidmaatschap & kleding",
  "club/vrijwilligers": "Vrijwilligers",
  "club/clubwaarden": "Clubwaarden",
  "club/documenten": "Clubdocumenten",
  "club/contact": "Contact",
  "teams": "Onze teams",
  "teams/trainingen": "Trainingstijden",
  "teams/walking-football": "Walking Football",
  "wedstrijden": "Wedstrijdcentrum",
  "wedstrijden/informatie": "Wedstrijdinformatie",
  "wedstrijden/afgelastingen": "Afgelastingen",
  "wedstrijden/oefenwedstrijd": "Oefenwedstrijd aanvragen",
  "nieuws": "Nieuws",
  "verhalen": "Verhalen & columns",
  "media/fotos": "Foto\u2019s van de club",
  "media/club-tv": "Duindorp SV-TV",
  "media/nieuwsbrief": "Nieuwsbrief"
};

// lib/clubmuur-history.ts
var clubHistoryTitle = "Duindorp SV: een club van de wijk, een geschiedenis om trots op te zijn";
var clubHistorySections = [
  {
    id: "een-club-van-de-wijk",
    label: "Een club van de wijk",
    period: "HET BEGIN",
    title: "Een eigen club voor Duindorp.",
    paragraphs: [
      "Wie over Duindorp SV vertelt, vertelt over de mensen uit de wijk. Over voetballers, families, vrijwilligers en supporters die samen een vereniging hebben opgebouwd. Over de wens om een eigen club te hebben, de zoektocht naar een thuis en de verbondenheid die van generatie op generatie wordt doorgegeven. In de geschiedenis van onze vereniging komen sportieve ambitie en liefde voor Duindorp steeds weer samen.",
      "Het verhaal begint al v\xF3\xF3r de offici\xEBle oprichting. In 1948 werden wijkbewoners opgeroepen om een eigen voetbalvereniging te helpen vormen. Er was behoefte aan sport en ontspanning, vooral voor de jeugd. Jan IJzendoorn, eigenaar van caf\xE9 Duinzicht, behoorde tot de mensen die zich daarvoor sterk maakten. In maart 1949 vestigde hij met een ingezonden brief opnieuw de aandacht op het gebrek aan voorzieningen in de wijk. Een sportvereniging moest daar verandering in brengen.",
      "Op 15 augustus 1950 werd de Duindorp Sport Vereniging opgericht. Die naam paste bij de brede opzet: naast voetbal kregen ook dameshandbal, korfbal, wandelen en volleybal een plek. Zelfs het vastleggen van de naam verliep niet zonder omwegen. De voorgestelde afkortingen S.V.D. en D.S.V. werden door de voetbalbond niet geaccepteerd. Uiteindelijk werd het Duindorp SV: de naam waaronder de vereniging haar eigen geschiedenis zou schrijven.",
      "De start was bescheiden. Geld en spelers waren schaars en een eigen veld in de wijk kwam er niet. Aan de Goudenregenstraat moest eerst oorlogsschade worden hersteld. Ook daarna waren tijdelijke oplossingen bij andere verenigingen nodig. Toch volgde meteen succes: in 1950-1951 werd het eerste elftal ongeslagen kampioen van de vierde klasse van de Haagse Voetbalbond."
    ]
  },
  {
    id: "samen-opgroeien",
    label: "Samen opgroeien",
    period: "GENERATIES IN BLAUW-WIT",
    title: "De club waar je samen opgroeit.",
    paragraphs: [
      "Voor veel jonge Duindorpers werd de vereniging ondertussen een vanzelfsprekend onderdeel van hun jeugd. Oud-speler Leen de Graaf herinnerde zich hoe de kinderen bij de sigarenwinkel van Piet Snabel verzamelden voordat zij naar Ockenburgh gingen. Daar konden ze ook zien of de wedstrijden waren afgelast. Hij speelde bij Duindorp met zijn vriendjes uit de wijk en keek daar tientallen jaren later nog met plezier op terug. Zijn herinneringen laten zien hoe nauw het dagelijkse leven in Duindorp en het verenigingsleven met elkaar verbonden waren. De club was de plek waar je samen opgroeide.",
      "Ook sportief kreeg de vereniging steeds meer geschiedenis. In het seizoen 1960-1961 werd Duindorp SV kampioen van de tweede klasse B van de Haagse Voetbalbond. In 1972-1973 volgde onder trainer Sicco Kuiper een kampioenschap in de eerste klasse B van diezelfde bond. Het waren mijlpalen die hun plaats kregen tussen de vele andere herinneringen aan wedstrijden, ploeggenoten en trainers."
    ]
  },
  {
    id: "thuis-op-houtrust",
    label: "Thuis op Houtrust",
    period: "EEN EIGEN THUIS",
    title: "Nieuwe hoofdstukken op Houtrust.",
    paragraphs: [
      "Een bijzonder belangrijk hoofdstuk begon in 1975, toen Duindorp SV op Houtrust de beschikking kreeg over het clubhuis en de twee velden. Daarmee kreeg de vereniging een thuis op grond die al een grote betekenis had voor het Haagse voetbal. Hier hadden HBS en Holland Sport hun geschiedenis geschreven; voortaan zou ook Duindorp SV er zijn eigen hoofdstukken aan toevoegen. De komst naar Houtrust gaf de club ruimte om verder te bouwen, met de inzet van vrijwilligers die de accommodatie en het verenigingsleven droegen.",
      "De herinneringen aan Houtrust gaan bovendien over veel meer teams dan alleen het eerste elftal. Vrouwen- en meisjesvoetbal hebben eveneens een plaats in onze geschiedenis. Zo won een meisjeszevental van Duindorp SV in 1994 de bekerfinale tegen RKDEO met 10-4. Ook zulke prestaties verdienen het om doorverteld te worden: ze horen bij het gezamenlijke verhaal van de vereniging."
    ]
  },
  {
    id: "bijzondere-ontmoetingen",
    label: "Bijzondere ontmoetingen",
    period: "VOETBAL VERBINDT",
    title: "Van Toms River tot Sterrenslag.",
    paragraphs: [
      "Soms bracht de club haar leden zelfs ver buiten Den Haag. In 1980 reisden drie jeugdelftallen naar de Verenigde Staten. De groep telde 82 personen. Met inzamelacties, de verkoop van pennen en aanstekers en eigen bijdragen werd een bijzondere voetbalreis naar Toms River mogelijk gemaakt.",
      "In de jaren tachtig kreeg Duindorp SV ook bekendheid door Sterrenslag. De eerste editie vond plaats op 5 mei 1981, met Krijn Turfboer als organisator. Het evenement bracht bekende namen uit de voetbalwereld naar Houtrust. Onder anderen Willem van Hanegem, Louis van Gaal en Danny Blind waren erbij betrokken, evenals teams van FC Utrecht, Sparta en oud-Holland Sport. De beelden en verhalen uit die tijd tonen een drukbezocht sportpark waar voetbal en gezelligheid elkaar versterkten. Sterrenslag werd een herkenbaar onderdeel van het Duindorpse verenigingsleven."
    ]
  },
  {
    id: "namen-en-mijlpalen",
    label: "Namen & mijlpalen",
    period: "OM TE KOESTEREN",
    title: "Namen, derby\u2019s en kampioenen.",
    paragraphs: [
      "Ook de naam Advocaat is aan de clubgeschiedenis verbonden. Jaap Advocaat was trainer van Duindorp SV, en zijn broer Dick speelde eveneens bij de vereniging. Oud-speler Daan Verbaan vertelde later hoe hij als voorstopper samen met Dick Advocaat als laatste man in de verdediging stond. In zijn herinneringen komen daarnaast de Haagse derby\u2019s terug: wedstrijden waarover al ruim v\xF3\xF3r de aftrap werd gesproken. Het zijn zulke persoonlijke verhalen die de clubhistorie een gezicht geven.",
      "In 2005 bereikte Duindorp SV onder Sjaak de Bruin, met Bennie de Roode en Karel Oosterbaan, voor het eerst de derde klasse van de KNVB. In 2010 koos de vereniging ervoor het prestatieve voetbal op zaterdag voort te zetten.",
      "Daar volgde opnieuw een moment om te koesteren. Op 21 mei 2011 won Duindorp SV de beslissingswedstrijd tegen Houtwijk met 3-0 en werd kampioen van de vierde klasse C. De wedstrijd werd gespeeld op het terrein van Quick. Een nieuwe kampioensfoto kon aan het archief worden toegevoegd, met een nieuwe groep spelers en begeleiders die samen een blijvende herinnering had gemaakt."
    ]
  },
  {
    id: "samen-verder-bouwen",
    label: "Samen verder bouwen",
    period: "DE KRACHT VAN DE VERENIGING",
    title: "Ook naast het veld vooruit.",
    paragraphs: [
      "Door de jaren heen moest er ook buiten het veld steeds worden gewerkt aan de toekomst. Een vereniging vraagt onderhoud, organisatie en mensen die verantwoordelijkheid willen nemen. In de periode rond 2018 en de jaren daarna werd daar opnieuw veel energie in gestoken. De kantine kreeg een nieuwe inrichting, kleedkamers en sanitair werden aangepakt en ook de speeltuin werd verbeterd. Eigen leden realiseerden onder meer een buitenterras en een nieuw ballenhok. Tegelijkertijd was er aandacht voor de jeugdopleiding, sponsors en de financi\xEBle positie van de club.",
      "Die ontwikkeling laat zien hoeveel een vereniging gezamenlijk kan bereiken. Bestuurders, vrijwilligers, leden en ondersteuners leverden ieder hun bijdrage. De inzet zat in grote projecten \xE9n in het terugkerende werk: schoonmaken, organiseren, trainen en zorgen dat de accommodatie gebruikt kon blijven worden.",
      "Op 24 september 2022 nam Duindorp SV het eerste kunstgrasveld officieel in gebruik, een belangrijke verbetering voor trainingen en wedstrijden."
    ]
  },
  {
    id: "geschiedenis-die-leeft",
    label: "Geschiedenis die leeft",
    period: "75 JAAR DUINDORP SV",
    title: "Een verhaal dat verdergaat.",
    paragraphs: [
      "De band met de Haagse voetbalgeschiedenis kreeg later ook een zichtbare plek in de Dag van de Haagse Voetbalhistorie op Houtrust. Voetballers en bezoekers komen er samen om te spelen, oude bekenden te ontmoeten en herinneringen op te halen. Daarmee blijft het verleden onderdeel van het clubleven. De vrijwilligers die zulke dagen mogelijk maken, voegen ondertussen zelf weer iets toe aan die geschiedenis.",
      "Op 15 augustus 2025 bestond Duindorp SV 75 jaar. Een mijlpaal die uitnodigt om terug te kijken naar alle mensen die de vereniging hebben gevormd. Naar de initiatiefnemers van toen, de generaties op het veld en iedereen die daarnaast het werk heeft verzet.",
      "Onze geschiedenis geeft ons veel om te bewaren en door te vertellen. Iedere nieuwe generatie krijgt de kans daar eigen herinneringen aan toe te voegen. Zo blijft Duindorp SV voortbouwen op wat in 1950 begon: een vereniging waarin de wijk, de sport en de mensen elkaar vinden."
    ]
  }
];

// lib/clubmuur-volunteer-story.json
var clubmuur_volunteer_story_default = {
  title: "Een vereniging zijn we samen",
  path: "/clubmuur/club/vrijwilligers",
  status: "published",
  source: "Door de gebruiker aangeleverde tekst op 13 oktober 2026",
  publicationNote: "Aanvullende instructie van de gebruiker op 13 oktober 2026: het vrijwilligersverhaal direct verwerken en publiceren.",
  paragraphs: [
    "Een voetbalvereniging draait om mensen. Om kinderen die met plezier trainen, teams die iedere week het veld op gaan en supporters die langs de lijn komen kijken. Om samen sporten, elkaar ontmoeten en je ergens thuis voelen. Achter dat alles staat een grote hoeveelheid werk. Werk dat bij een vereniging als Duindorp SV voor een belangrijk deel wordt gedaan door vrijwilligers.",
    "Duindorp SV is een vereniging, geen bedrijf. Onze club bestaat voor en door haar leden. De contributie en de steun van sponsors helpen om de kosten te dragen, maar daarmee is het werk nog niet gedaan. Er moeten trainingen worden gegeven, wedstrijden worden geregeld, materialen worden onderhouden en kleedkamers worden schoongemaakt. De kantine moet draaien, de administratie moet kloppen en activiteiten moeten worden georganiseerd. Dat vraagt om mensen die zich daar samen voor willen inzetten.",
    "Juist voor een wijkvereniging als Duindorp SV is die vrijwillige inzet onmisbaar. Dankzij vrijwilligers kunnen we het voetbal toegankelijk en betaalbaar houden en tegelijk een plek bieden waar jong en oud graag komt. Zij zorgen voor de vertrouwde gezichten, de aandacht voor onze jeugd en de gastvrijheid die bij onze club horen. Daarmee geven ze onze vereniging haar karakter.",
    "Veel van hun werk valt pas op wanneer het een keer niet gebeurt. We vinden het al snel normaal dat het veld klaarstaat, er een trainer aanwezig is en de koffie wordt geschonken. Toch zit achter al die vanzelfsprekende dingen iemand die daar tijd voor vrijmaakt. Vaak naast een baan, een gezin en andere verplichtingen. Die betrokkenheid verdient onze waardering.",
    "Die waardering zit ook in hoe we met elkaar omgaan. In een bedankje, begrip wanneer iets anders loopt dan gehoopt en respect voor het werk dat wordt gedaan. In je spullen opruimen, de accommodatie netjes achterlaten of even vragen of je ergens bij kunt helpen. Zo ondersteunen we de mensen die zich voor ons allemaal inzetten.",
    "Niemand hoeft alles te kunnen of overal tijd voor te hebben. De \xE9\xE9n vervult een vaste taak, de ander helpt bij een activiteit of springt af en toe bij. Iedere bijdrage, passend bij iemands mogelijkheden, helpt om het werk samen te dragen.",
    "Aan iedereen die zich inzet voor Duindorp SV: we waarderen jullie enorm. Jullie geven onze leden de mogelijkheid om te sporten, plezier te maken en onderdeel te zijn van een hechte club. Dat is van grote waarde, iedere week opnieuw.",
    "Onze vereniging bestaat dankzij mensen die er samen iets van maken. Onze vrijwilligers zijn daarin onmisbaar."
  ]
};

// lib/clubmuur-people.ts
var clubBoardContacts = {
  secretariatEmail: "secretariaat@duindorpsv.nl",
  chairmanEmail: "danny.goldenbelt@duindorpsv.nl",
  chairmanPhone: "0659019035"
};
var boardPeople = [
  { id: "voorzitter", name: "Danny Goldenbelt", role: "Voorzitter", department: "Verbinding & koers", summary: "Voorzitter van Duindorp SV. Ook vermeld als aanspreekpunt voor kantinezaken.", responsibilities: ["Algemene bestuurlijke vragen.", "De verbinding tussen bestuur en vereniging.", "Kantinezaken."] },
  { id: "secretaris", name: "Corine de Jong", role: "Secretaris", department: "Organisatie & afspraken", summary: "Het aanspreekpunt voor het secretariaat van onze vereniging.", responsibilities: ["Vragen voor het secretariaat.", "Verenigingscorrespondentie.", "Bestuurlijke afspraken en doorverwijzing."] },
  { id: "penningmeester", name: "Wilco van Doorn", role: "Penningmeester", department: "Financi\xEBn", summary: "De financi\xEBle portefeuille binnen het bestuur.", responsibilities: ["Financi\xEBle verenigingszaken.", "Vragen voor de penningmeester.", "Afstemming over inkomsten en uitgaven."] },
  { id: "algemene-zaken", name: "Andr\xE9 den Heijer", role: "Algemene zaken", department: "De dagelijkse club", summary: "Verantwoordelijk voor de portefeuille algemene zaken.", responsibilities: ["Algemene verenigingszaken.", "Praktische vragen voor het bestuur.", "Afstemming met de betrokkenen binnen de club."] },
  { id: "hff", name: "Sander Roeleveld", role: "Co\xF6rdinator HFF", department: "Co\xF6rdinatie", summary: "Binnen het bestuur vermeld als co\xF6rdinator HFF.", responsibilities: ["Vragen over de HFF-co\xF6rdinatie.", "Afstemming rondom deze portefeuille.", "Doorverwijzing naar het juiste aanspreekpunt."] },
  { id: "technische-commissie", name: "Michel Simonis", role: "Technische commissie jeugd en senioren", department: "Jeugd & senioren", summary: "De technische commissie voor jeugd en senioren binnen het bestuur.", responsibilities: ["Vragen over technische voetbalzaken voor jeugd en senioren.", "Afstemming met de technische organisatie.", "De verbinding tussen jeugd- en seniorenvoetbal en het bestuur."] }
].map((person) => ({ ...person, email: person.id === "voorzitter" ? clubBoardContacts.chairmanEmail : clubBoardContacts.secretariatEmail, phone: person.id === "voorzitter" ? clubBoardContacts.chairmanPhone : void 0 }));
var clubCommissions = [
  { id: "wedstrijdzaken", title: "Wedstrijdzaken", category: "Voetbal", summary: "Alles rondom het organiseren van onze wedstrijden.", tasks: ["Afstemming over het wedstrijdprogramma.", "Vragen over wedstrijdorganisatie en wijzigingen.", "Bezoekers en teams naar de juiste informatie begeleiden."], contactLabel: "Vraag over wedstrijdzaken", contactName: "Ricardo Dekker \xB7 Erwin Kooijenga", contactRole: "Wedstrijdsecretaris senioren \xB7 jeugd" },
  { id: "technische-commissie", title: "Technische commissie jeugd en senioren", category: "Voetbal", summary: "Samen werken aan de ontwikkeling van ons jeugd- en seniorenvoetbal.", tasks: ["Afstemming over voetbalinhoudelijke zaken voor jeugd en senioren.", "Ondersteuning van trainers en teambegeleiders.", "Samenwerking tussen de verschillende teams."], contactLabel: "Vraag over voetbalzaken", contactName: "Michel Simonis", contactRole: "Technische commissie jeugd en senioren" },
  { id: "jeugdcommissie", title: "Jeugdcommissie", category: "Voetbal", summary: "Van de eerste training tot de volgende stap.", tasks: ["Ondersteuning van jeugdteams en ouders.", "Afstemming met jeugdco\xF6rdinatoren.", "Meedenken over jeugdactiviteiten en voetbalplezier."], contactLabel: "Vraag over de jeugd", contactName: "Anthony Pronk", contactRole: "Voorzitter jeugdbestuur" },
  { id: "vrijwilligers", title: "Vrijwilligers", category: "Club & mensen", summary: "Een uurtje, een talent of een goed idee: iedereen kan iets bijdragen.", tasks: ["Nieuwe helpers de weg wijzen.", "Vraag en aanbod van vrijwilligerstaken verbinden.", "Meedenken over een passende rol binnen de club."], contactLabel: "Vraag over vrijwilligerswerk" },
  { id: "activiteiten", title: "Activiteiten & ontmoeting", category: "Club & mensen", summary: "De momenten die van een vereniging een club maken.", tasks: ["Meedenken over activiteiten voor leden en de wijk.", "Samenwerking met vrijwilligers en teams.", "Ruimte voor idee\xEBn die mensen bij elkaar brengen."], contactLabel: "Deel een idee voor de club" },
  { id: "sponsoring", title: "Sponsoring & communicatie", category: "Club & mensen", summary: "Onze verhalen, onze partners en de zichtbaarheid van de club.", tasks: ["Vragen over samenwerking en sponsoring.", "Nieuws en clubverhalen verzamelen.", "Afstemming over communicatie en publicaties."], contactLabel: "Vraag over samenwerking" },
  { id: "kantine", title: "Kantine", category: "Accommodatie", summary: "Een gastvrije ontmoetingsplek voor en na het voetbal.", tasks: ["Afstemming over kantinevrijwilligers.", "Praktische vragen over het clubhuis.", "Meedenken over een prettige ontvangst van bezoekers."], contactLabel: "Vraag over de kantine", contactName: "Danny Goldenbelt", contactRole: "Kantinezaken" },
  { id: "terrein", title: "Terrein & materialen", category: "Accommodatie", summary: "Zorgen voor de plek waar ons voetbal begint.", tasks: ["Signaleren van onderhoud aan terrein en accommodatie.", "Afstemming over voetbalmaterialen.", "Samenwerken aan een verzorgd sportpark."], contactLabel: "Vraag over accommodatie", contactName: "Ricardo Dekker", contactRole: "Facilitaire zaken" }
];
var youthPeople = [
  { id: "jeugdvoorzitter", name: "Anthony Pronk", role: "Voorzitter jeugdbestuur", department: "Samenhang & organisatie", summary: "Voorzitter van het jeugdbestuur van Duindorp SV.", responsibilities: ["Algemene vragen voor het jeugdbestuur.", "De organisatie rondom de jeugdafdeling.", "Afstemming met betrokkenen binnen de vereniging."] },
  { id: "jeugdbestuur", name: "Rinus Taal", role: "Jeugdbestuur", department: "Jeugdorganisatie", summary: "Onderdeel van het jeugdbestuur van onze vereniging.", responsibilities: ["Vragen over de jeugdorganisatie.", "Doorverwijzing binnen de jeugdafdeling.", "Afstemming over jeugdzaken."] },
  { id: "hjo", name: "Herman Kooijenga", role: "Hoofd jeugdopleiding", department: "Voetbal & ontwikkeling", summary: "Op de clubwebsite vermeld als HJO.", responsibilities: ["Vragen over de jeugdopleiding.", "Afstemming over voetbalontwikkeling.", "Voetbalinhoudelijke vragen voor de jeugdorganisatie."] },
  { id: "hoofdcoordinator", name: "Ferdi Aydin", role: "Hoofdco\xF6rdinator", department: "Samenhang tussen teams", summary: "Het centrale aanspreekpunt voor de jeugdco\xF6rdinatie.", responsibilities: ["Vragen over de jeugdco\xF6rdinatie.", "Afstemming met de leeftijdsco\xF6rdinatoren.", "De verbinding tussen de verschillende jeugdgroepen."] },
  { id: "coordinator-junioren", name: "Ricardo Van Gorsel", role: "Co\xF6rdinator bovenbouw", department: "De volgende stap", summary: "Het aanspreekpunt voor de bovenbouw.", responsibilities: ["Vragen over de bovenbouw.", "Afstemming met de betrokken teams.", "Doorverwijzing naar trainers en begeleiders."] },
  { id: "coordinator-pupillen", name: "Edwin Kaffa", role: "Co\xF6rdinator onderbouw", department: "Plezier in ontwikkeling", summary: "Het aanspreekpunt voor de onderbouw.", responsibilities: ["Vragen over de onderbouw.", "Ouders de juiste weg wijzen.", "Afstemming met de betrokken teams."] },
  { id: "coordinator-meiden", name: "Erwin Kooijenga", role: "Co\xF6rdinator meiden", department: "Samen voetballen", summary: "Het aanspreekpunt voor de meidenafdeling. Ook wedstrijdsecretaris jeugd.", responsibilities: ["Vragen over meidenvoetbal.", "Afstemming met de betrokken teams.", "Wedstrijdzaken voor de jeugd."] }
];

// lib/cms/featured.ts
var WEEK = 7 * 24 * 60 * 60 * 1e3;

// lib/cms/model.ts
var emptySEO = () => ({ title: "", description: "", noIndex: false });
var textDoc = (paragraphs) => ({ type: "doc", content: paragraphs.map((text3) => ({ type: "paragraph", content: text3 ? [{ type: "text", text: text3 }] : [] })) });
var docText = (doc) => doc.text || (doc.content || []).map(docText).join(doc.type === "doc" ? "\n" : " ");
function articleContent(a) {
  const { contentType, storyFormat, title, slug, intro, body, coverId, authorId, author, category, tags, teamId, season, seo, featured, featuredUntil, publishedAt } = a;
  return structuredClone({ contentType, storyFormat, title, slug, intro, body, coverId, ...authorId ? { authorId } : {}, author, category, tags, teamId, season, seo, featured, ...featuredUntil !== void 0 ? { featuredUntil } : {}, publishedAt });
}
function pageContent(p) {
  const { coverId, coverSrc, bodyFormat, title, slug, intro, body, parentId, menuGroup, menuVisible, order, seo, useBuilder } = p;
  return structuredClone({ ...coverId !== void 0 ? { coverId } : {}, ...coverSrc !== void 0 ? { coverSrc } : {}, ...bodyFormat ? { bodyFormat } : {}, title, slug, intro, body, parentId, menuGroup, menuVisible, order, seo, useBuilder });
}

// lib/cms/seed.ts
function createCmsSeed() {
  const date = "2026-10-13T09:00:00.000Z";
  const photoNames = ["Langs de lijn", "De volgende generatie", "Achter de schermen", "Een leven lang"];
  const photos = ["supporters", "youth", "canteen", "walking"].map((id, i) => ({ id: `photo-${id}`, name: photoNames[i], src: `/assets/club-life-v28/${id}-1280.webp`, folderId: "clubleven", alt: `${photoNames[i]} bij de voetbalclub`, caption: ["Samen kijken. Samen meeleven. Dat is het clubgevoel.", "De eerste bal, nieuwe vrienden en plezier voorop.", "De mensen die van een zaterdag een clubdag maken.", "Het spel blijft verbinden."][i], credit: "", teamId: "", season: "2026\u20132027", published: true, featured: true, order: i, focusX: 50, focusY: 45, createdAt: date }));
  const covers = [...new Set(articles.map((a) => a.image))].map((src, i) => ({ id: `cover-${i}`, name: src.split("/").pop() || "Omslagfoto", src, folderId: "nieuws", alt: "Sfeerbeeld Duindorp SV", caption: "", credit: "", teamId: "", season: "2026\u20132027", published: true, featured: false, order: i, focusX: 50, focusY: 50, createdAt: date }));
  const articles2 = articles.map((a, i) => {
    const row2 = { id: a.id, contentType: ["samen-langs-de-lijn", "iedereen-doet-mee", "vrijwilligers", "walking-football"].includes(a.id) ? "story" : "news", storyFormat: a.id === "samen-langs-de-lijn" ? "column" : "story", title: a.title, slug: a.id, intro: a.intro, body: textDoc(a.body), coverId: covers.find((m) => m.src === a.image)?.id || "", author: "Redactie Duindorp SV", category: a.category, tags: [], teamId: "", season: "2026\u20132027", seo: { title: a.title, description: a.intro, noIndex: false }, featured: i < 3, publishedAt: `2026-10-${String([8, 7, 6, 5, 3, 1][i]).padStart(2, "0")}T08:00:00.000Z`, status: "published", updatedAt: date, scheduledAt: "", revisions: [], demo: true };
    row2.live = articleContent(row2);
    return row2;
  });
  const pages = clubContentPaths.filter((path) => path !== "media/fotos").map((path, i) => {
    let body = textDoc([]);
    let intro = "";
    if (path === "club/ons-verhaal") {
      intro = clubHistoryTitle;
      body = { type: "doc", content: [...clubHistorySections.flatMap((s) => [{ type: "heading", attrs: { level: 2 }, content: [{ type: "text", text: s.title }] }, ...textDoc(s.paragraphs).content]), { type: "paragraph", content: [{ type: "text", text: "Bron: De Haagse Voetbalhistorie \u2013 Duindorp SV, aangevuld met interviews en historische artikelen uit hetzelfde archief, de clubwebsite van Duindorp SV, Haaglanden Voetbal en Het Haags Amateurvoetbal.", marks: [{ type: "link", attrs: { href: "https://dehaagsevoetbalhistorie.nl/club/duindorp_sv/" } }] }] }] };
    }
    if (path === "club/vrijwilligers") {
      intro = clubmuur_volunteer_story_default.title;
      body = textDoc(clubmuur_volunteer_story_default.paragraphs);
    }
    if (path === "club/bestuur") {
      intro = "De mensen die samen verantwoordelijkheid nemen voor onze vereniging.";
      body = { type: "doc", content: [{ type: "cmsWidget", attrs: { kind: "people", data: { title: "Het bestuur", layout: "Bestuur" } } }, { type: "cmsWidget", attrs: { kind: "contact", data: { title: "Bereikbaarheid bestuur", refId: "secretariaat" } } }] };
    }
    if (path === "club/jeugdorganisatie") {
      intro = "Samen geven we onze jeugd ruimte om te groeien.";
      body = { type: "doc", content: [{ type: "cmsWidget", attrs: { kind: "people", data: { title: "Jeugdorganisatie", layout: "Jeugdorganisatie" } } }] };
    }
    const blueprint = club_pages_default[path];
    if (blueprint) {
      intro = blueprint.intro;
      body = blueprint.body;
    }
    body = migrateLayout(body, `page-${path.replaceAll("/", "-")}`);
    const row2 = { id: `page-${path.replaceAll("/", "-")}`, title: clubContentTitles[path] || path, ...blueprint?.coverSrc ? { coverSrc: blueprint.coverSrc } : {}, slug: path, intro, body, parentId: path === "club" ? "" : path.startsWith("club/") ? "page-club" : "", menuGroup: path.startsWith("media/") ? "nieuws" : path.split("/")[0], menuVisible: !["wedstrijden/oefenwedstrijd", "media/club-tv"].includes(path), order: i, seo: emptySEO(), bodyFormat: "page-layout-v2", useBuilder: true, status: "published", updatedAt: date, revisions: [], system: true };
    row2.live = pageContent(row2);
    return row2;
  });
  const allPermissions = ["news", "pages", "media", "people", "forms", "settings", "users", "publish"];
  return { planning: { committees: [], locations: [], activities: [], lastSportlinkSync: null }, schemaVersion: 1, articles: articles2, pages, media: [...photos, ...covers], folders: [{ id: "clubleven", name: "Het clubleven" }, { id: "nieuws", name: "Nieuws & verhalen" }], albums: [{ id: "album-clubleven", title: "Dit zijn wij", slug: "dit-zijn-wij", description: "Op het veld, langs de lijn en aan de bar. Vier sfeerbeelden van het clubgevoel.", date: "2026-10-13", teamId: "", season: "2026\u20132027", coverId: photos[0].id, mediaIds: photos.map((m) => m.id), published: true, order: 0 }], people: [...clubCommissions.map((p, i) => ({ id: `commissie-${p.id}`, name: p.contactName || p.title, role: p.contactRole || p.title, group: "Commissies", teamId: "", bio: [p.summary, ...p.tasks].join("\n"), mediaId: "", email: p.id === "sponsoring" ? "sponsoring@duindorpsv.nl" : "secretariaat@duindorpsv.nl", phone: "", showContact: true, published: true, order: i })), ...boardPeople.map((p, i) => ({ id: p.id, name: p.name || "", role: p.role, group: "Bestuur", teamId: "", bio: p.summary, mediaId: "", email: p.email || "secretariaat@duindorpsv.nl", phone: p.phone || "", showContact: true, published: true, order: i })), ...youthPeople.map((p, i) => ({ id: p.id, name: p.name || "", role: p.role, group: "Jeugdorganisatie", teamId: "", bio: p.summary, mediaId: "", email: "secretariaat@duindorpsv.nl", phone: "", showContact: true, published: true, order: i }))], departments: [{ id: "sponsoring", name: "Sponsoring", description: "Sponsor worden bij Duindorp SV", emails: ["sponsoring@duindorpsv.nl"], active: true, confirmation: "Bedankt voor je sponsoraanvraag. De sponsorcommissie neemt contact met je op." }, { id: "secretariaat", name: "Secretariaat", description: "Algemene vragen over de vereniging", emails: ["secretariaat@duindorpsv.nl"], active: true, confirmation: "Bedankt voor je bericht. Het secretariaat komt bij je terug." }, { id: "voorzitter", name: "Voorzitter", description: "Vragen voor het bestuur en de voorzitter", emails: ["danny.goldenbelt@duindorpsv.nl"], active: true, confirmation: "Bedankt voor je bericht aan de voorzitter." }], forms: [...structuredClone(publicFormPresets), { id: "activity-signup", kind: "registration", name: "Aanmelding clubactiviteit", departmentId: "secretariaat", active: true, retentionDays: 90, fields: [{ id: "name", label: "Naam deelnemer", type: "text", required: true }, { id: "email", label: "E-mailadres", type: "email", required: true }, { id: "activity", label: "Activiteit", type: "text", required: true }, { id: "phone", label: "Telefoonnummer", type: "tel", required: false }, { id: "message", label: "Opmerking", type: "textarea", required: false }] }, { id: "volunteer-request", kind: "request", name: "Aanvraag kennismaking vrijwilligerswerk", departmentId: "secretariaat", active: true, retentionDays: 90, fields: [{ id: "name", label: "Naam", type: "text", required: true }, { id: "email", label: "E-mailadres", type: "email", required: true }, { id: "task", label: "Waar wil je bij helpen?", type: "text", required: true }, { id: "message", label: "Beschikbaarheid en toelichting", type: "textarea", required: true }] }], submissions: [], roles: [{ id: "admin", name: "Beheerder", description: "Volledig beheer van het CMS en instellingen.", permissions: allPermissions, teamScoped: false }, { id: "chief", name: "Hoofdredacteur", description: "Redactie, pagina\u2019s, personen, media en publicatie.", permissions: ["news", "pages", "people", "media", "publish"], teamScoped: false }, { id: "editor", name: "Redacteur", description: "Nieuws en pagina\u2019s voorbereiden voor beoordeling.", permissions: ["news", "pages", "media"], teamScoped: false }, { id: "team", name: "Teamredacteur", description: "Nieuws voor toegewezen teams voorbereiden.", permissions: ["news", "media"], teamScoped: true }, { id: "photographer", name: "Fotograaf", description: "Foto\u2019s en albums voorbereiden voor publicatie.", permissions: ["media"], teamScoped: false }], members: [{ id: "demo-admin", name: "Demo beheerder", email: "", roleId: "admin", teamIds: [], active: true }, { id: "demo-team", name: "Demo teamredacteur", email: "", roleId: "team", teamIds: ["1"], active: true }], documents: [], settings: { clubName: "Duindorp SV", siteDescription: "Onze wijk. Onze club. Onze trots.", contactEmail: "secretariaat@duindorpsv.nl", season: "2026\u20132027", newsCategories: ["Clubnieuws", "Vereniging", "Eerste elftal", "Jeugd", "Voetbal"], teams: teams.map((t) => ({ id: t.id, name: t.name })), homepageArticleIds: articles2.filter((a) => a.contentType === "news" && a.featured).map((a) => a.id), homepageStoryIds: articles2.filter((a) => a.contentType === "story" && a.featured).map((a) => a.id), homepageAlbumIds: ["album-clubleven"], homepagePhotoIds: photos.map((p) => p.id), homepageHeading: "Dit zijn wij.", newsletterEnabled: true, newsletterLabel: "Blijf op de hoogte van de club", socials: [] }, redirects: articles2.filter((a) => a.contentType === "story").map((a) => ({ from: `nieuws/${a.slug}`, to: `verhalen/${a.slug}` })), audit: [] };
}

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/external.js
var external_exports = {};
__export(external_exports, {
  BRAND: () => BRAND,
  DIRTY: () => DIRTY,
  EMPTY_PATH: () => EMPTY_PATH,
  INVALID: () => INVALID,
  NEVER: () => NEVER,
  OK: () => OK,
  ParseStatus: () => ParseStatus,
  Schema: () => ZodType,
  ZodAny: () => ZodAny,
  ZodArray: () => ZodArray,
  ZodBigInt: () => ZodBigInt,
  ZodBoolean: () => ZodBoolean,
  ZodBranded: () => ZodBranded,
  ZodCatch: () => ZodCatch,
  ZodDate: () => ZodDate,
  ZodDefault: () => ZodDefault,
  ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
  ZodEffects: () => ZodEffects,
  ZodEnum: () => ZodEnum,
  ZodError: () => ZodError,
  ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
  ZodFunction: () => ZodFunction,
  ZodIntersection: () => ZodIntersection,
  ZodIssueCode: () => ZodIssueCode,
  ZodLazy: () => ZodLazy,
  ZodLiteral: () => ZodLiteral,
  ZodMap: () => ZodMap,
  ZodNaN: () => ZodNaN,
  ZodNativeEnum: () => ZodNativeEnum,
  ZodNever: () => ZodNever,
  ZodNull: () => ZodNull,
  ZodNullable: () => ZodNullable,
  ZodNumber: () => ZodNumber,
  ZodObject: () => ZodObject,
  ZodOptional: () => ZodOptional,
  ZodParsedType: () => ZodParsedType,
  ZodPipeline: () => ZodPipeline,
  ZodPromise: () => ZodPromise,
  ZodReadonly: () => ZodReadonly,
  ZodRecord: () => ZodRecord,
  ZodSchema: () => ZodType,
  ZodSet: () => ZodSet,
  ZodString: () => ZodString,
  ZodSymbol: () => ZodSymbol,
  ZodTransformer: () => ZodEffects,
  ZodTuple: () => ZodTuple,
  ZodType: () => ZodType,
  ZodUndefined: () => ZodUndefined,
  ZodUnion: () => ZodUnion,
  ZodUnknown: () => ZodUnknown,
  ZodVoid: () => ZodVoid,
  addIssueToContext: () => addIssueToContext,
  any: () => anyType,
  array: () => arrayType,
  bigint: () => bigIntType,
  boolean: () => booleanType,
  coerce: () => coerce,
  custom: () => custom,
  date: () => dateType,
  datetimeRegex: () => datetimeRegex,
  defaultErrorMap: () => en_default,
  discriminatedUnion: () => discriminatedUnionType,
  effect: () => effectsType,
  enum: () => enumType,
  function: () => functionType,
  getErrorMap: () => getErrorMap,
  getParsedType: () => getParsedType,
  instanceof: () => instanceOfType,
  intersection: () => intersectionType,
  isAborted: () => isAborted,
  isAsync: () => isAsync,
  isDirty: () => isDirty,
  isValid: () => isValid,
  late: () => late,
  lazy: () => lazyType,
  literal: () => literalType,
  makeIssue: () => makeIssue,
  map: () => mapType,
  nan: () => nanType,
  nativeEnum: () => nativeEnumType,
  never: () => neverType,
  null: () => nullType,
  nullable: () => nullableType,
  number: () => numberType,
  object: () => objectType,
  objectUtil: () => objectUtil,
  oboolean: () => oboolean,
  onumber: () => onumber,
  optional: () => optionalType,
  ostring: () => ostring,
  pipeline: () => pipelineType,
  preprocess: () => preprocessType,
  promise: () => promiseType,
  quotelessJson: () => quotelessJson,
  record: () => recordType,
  set: () => setType,
  setErrorMap: () => setErrorMap,
  strictObject: () => strictObjectType,
  string: () => stringType,
  symbol: () => symbolType,
  transformer: () => effectsType,
  tuple: () => tupleType,
  undefined: () => undefinedType,
  union: () => unionType,
  unknown: () => unknownType,
  util: () => util,
  void: () => voidType
});

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/util.js
var util;
(function(util2) {
  util2.assertEqual = (_) => {
  };
  function assertIs(_arg) {
  }
  util2.assertIs = assertIs;
  function assertNever(_x) {
    throw new Error();
  }
  util2.assertNever = assertNever;
  util2.arrayToEnum = (items) => {
    const obj = {};
    for (const item of items) {
      obj[item] = item;
    }
    return obj;
  };
  util2.getValidEnumValues = (obj) => {
    const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
    const filtered = {};
    for (const k of validKeys) {
      filtered[k] = obj[k];
    }
    return util2.objectValues(filtered);
  };
  util2.objectValues = (obj) => {
    return util2.objectKeys(obj).map(function(e) {
      return obj[e];
    });
  };
  util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
    const keys = [];
    for (const key2 in object) {
      if (Object.prototype.hasOwnProperty.call(object, key2)) {
        keys.push(key2);
      }
    }
    return keys;
  };
  util2.find = (arr, checker) => {
    for (const item of arr) {
      if (checker(item))
        return item;
    }
    return void 0;
  };
  util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
  function joinValues(array, separator = " | ") {
    return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
  }
  util2.joinValues = joinValues;
  util2.jsonStringifyReplacer = (_, value) => {
    if (typeof value === "bigint") {
      return value.toString();
    }
    return value;
  };
})(util || (util = {}));
var objectUtil;
(function(objectUtil2) {
  objectUtil2.mergeShapes = (first, second) => {
    return {
      ...first,
      ...second
      // second overwrites first
    };
  };
})(objectUtil || (objectUtil = {}));
var ZodParsedType = util.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]);
var getParsedType = (data) => {
  const t = typeof data;
  switch (t) {
    case "undefined":
      return ZodParsedType.undefined;
    case "string":
      return ZodParsedType.string;
    case "number":
      return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
    case "boolean":
      return ZodParsedType.boolean;
    case "function":
      return ZodParsedType.function;
    case "bigint":
      return ZodParsedType.bigint;
    case "symbol":
      return ZodParsedType.symbol;
    case "object":
      if (Array.isArray(data)) {
        return ZodParsedType.array;
      }
      if (data === null) {
        return ZodParsedType.null;
      }
      if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
        return ZodParsedType.promise;
      }
      if (typeof Map !== "undefined" && data instanceof Map) {
        return ZodParsedType.map;
      }
      if (typeof Set !== "undefined" && data instanceof Set) {
        return ZodParsedType.set;
      }
      if (typeof Date !== "undefined" && data instanceof Date) {
        return ZodParsedType.date;
      }
      return ZodParsedType.object;
    default:
      return ZodParsedType.unknown;
  }
};

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/ZodError.js
var ZodIssueCode = util.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
var quotelessJson = (obj) => {
  const json = JSON.stringify(obj, null, 2);
  return json.replace(/"([^"]+)":/g, "$1:");
};
var ZodError = class _ZodError extends Error {
  get errors() {
    return this.issues;
  }
  constructor(issues) {
    super();
    this.issues = [];
    this.addIssue = (sub) => {
      this.issues = [...this.issues, sub];
    };
    this.addIssues = (subs = []) => {
      this.issues = [...this.issues, ...subs];
    };
    const actualProto = new.target.prototype;
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(this, actualProto);
    } else {
      this.__proto__ = actualProto;
    }
    this.name = "ZodError";
    this.issues = issues;
  }
  format(_mapper) {
    const mapper = _mapper || function(issue) {
      return issue.message;
    };
    const fieldErrors = { _errors: [] };
    const processError = (error) => {
      for (const issue of error.issues) {
        if (issue.code === "invalid_union") {
          issue.unionErrors.map(processError);
        } else if (issue.code === "invalid_return_type") {
          processError(issue.returnTypeError);
        } else if (issue.code === "invalid_arguments") {
          processError(issue.argumentsError);
        } else if (issue.path.length === 0) {
          fieldErrors._errors.push(mapper(issue));
        } else {
          let curr = fieldErrors;
          let i = 0;
          while (i < issue.path.length) {
            const el = issue.path[i];
            const terminal = i === issue.path.length - 1;
            if (!terminal) {
              curr[el] = curr[el] || { _errors: [] };
            } else {
              curr[el] = curr[el] || { _errors: [] };
              curr[el]._errors.push(mapper(issue));
            }
            curr = curr[el];
            i++;
          }
        }
      }
    };
    processError(this);
    return fieldErrors;
  }
  static assert(value) {
    if (!(value instanceof _ZodError)) {
      throw new Error(`Not a ZodError: ${value}`);
    }
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(mapper = (issue) => issue.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of this.issues) {
      if (sub.path.length > 0) {
        const firstEl = sub.path[0];
        fieldErrors[firstEl] = fieldErrors[firstEl] || [];
        fieldErrors[firstEl].push(mapper(sub));
      } else {
        formErrors.push(mapper(sub));
      }
    }
    return { formErrors, fieldErrors };
  }
  get formErrors() {
    return this.flatten();
  }
};
ZodError.create = (issues) => {
  const error = new ZodError(issues);
  return error;
};

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/locales/en.js
var errorMap = (issue, _ctx) => {
  let message;
  switch (issue.code) {
    case ZodIssueCode.invalid_type:
      if (issue.received === ZodParsedType.undefined) {
        message = "Required";
      } else {
        message = `Expected ${issue.expected}, received ${issue.received}`;
      }
      break;
    case ZodIssueCode.invalid_literal:
      message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
      break;
    case ZodIssueCode.unrecognized_keys:
      message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
      break;
    case ZodIssueCode.invalid_union:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_union_discriminator:
      message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
      break;
    case ZodIssueCode.invalid_enum_value:
      message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
      break;
    case ZodIssueCode.invalid_arguments:
      message = `Invalid function arguments`;
      break;
    case ZodIssueCode.invalid_return_type:
      message = `Invalid function return type`;
      break;
    case ZodIssueCode.invalid_date:
      message = `Invalid date`;
      break;
    case ZodIssueCode.invalid_string:
      if (typeof issue.validation === "object") {
        if ("includes" in issue.validation) {
          message = `Invalid input: must include "${issue.validation.includes}"`;
          if (typeof issue.validation.position === "number") {
            message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
          }
        } else if ("startsWith" in issue.validation) {
          message = `Invalid input: must start with "${issue.validation.startsWith}"`;
        } else if ("endsWith" in issue.validation) {
          message = `Invalid input: must end with "${issue.validation.endsWith}"`;
        } else {
          util.assertNever(issue.validation);
        }
      } else if (issue.validation !== "regex") {
        message = `Invalid ${issue.validation}`;
      } else {
        message = "Invalid";
      }
      break;
    case ZodIssueCode.too_small:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "bigint")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.too_big:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "bigint")
        message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.custom:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_intersection_types:
      message = `Intersection results could not be merged`;
      break;
    case ZodIssueCode.not_multiple_of:
      message = `Number must be a multiple of ${issue.multipleOf}`;
      break;
    case ZodIssueCode.not_finite:
      message = "Number must be finite";
      break;
    default:
      message = _ctx.defaultError;
      util.assertNever(issue);
  }
  return { message };
};
var en_default = errorMap;

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/errors.js
var overrideErrorMap = en_default;
function setErrorMap(map) {
  overrideErrorMap = map;
}
function getErrorMap() {
  return overrideErrorMap;
}

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/parseUtil.js
var makeIssue = (params) => {
  const { data, path, errorMaps, issueData } = params;
  const fullPath = [...path, ...issueData.path || []];
  const fullIssue = {
    ...issueData,
    path: fullPath
  };
  if (issueData.message !== void 0) {
    return {
      ...issueData,
      path: fullPath,
      message: issueData.message
    };
  }
  let errorMessage = "";
  const maps = errorMaps.filter((m) => !!m).slice().reverse();
  for (const map of maps) {
    errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
  }
  return {
    ...issueData,
    path: fullPath,
    message: errorMessage
  };
};
var EMPTY_PATH = [];
function addIssueToContext(ctx, issueData) {
  const overrideMap = getErrorMap();
  const issue = makeIssue({
    issueData,
    data: ctx.data,
    path: ctx.path,
    errorMaps: [
      ctx.common.contextualErrorMap,
      // contextual error map is first priority
      ctx.schemaErrorMap,
      // then schema-bound map if available
      overrideMap,
      // then global override map
      overrideMap === en_default ? void 0 : en_default
      // then global default map
    ].filter((x) => !!x)
  });
  ctx.common.issues.push(issue);
}
var ParseStatus = class _ParseStatus {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    if (this.value === "valid")
      this.value = "dirty";
  }
  abort() {
    if (this.value !== "aborted")
      this.value = "aborted";
  }
  static mergeArray(status, results) {
    const arrayValue = [];
    for (const s of results) {
      if (s.status === "aborted")
        return INVALID;
      if (s.status === "dirty")
        status.dirty();
      arrayValue.push(s.value);
    }
    return { status: status.value, value: arrayValue };
  }
  static async mergeObjectAsync(status, pairs) {
    const syncPairs = [];
    for (const pair of pairs) {
      const key2 = await pair.key;
      const value = await pair.value;
      syncPairs.push({
        key: key2,
        value
      });
    }
    return _ParseStatus.mergeObjectSync(status, syncPairs);
  }
  static mergeObjectSync(status, pairs) {
    const finalObject = {};
    for (const pair of pairs) {
      const { key: key2, value } = pair;
      if (key2.status === "aborted")
        return INVALID;
      if (value.status === "aborted")
        return INVALID;
      if (key2.status === "dirty")
        status.dirty();
      if (value.status === "dirty")
        status.dirty();
      if (key2.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
        finalObject[key2.value] = value.value;
      }
    }
    return { status: status.value, value: finalObject };
  }
};
var INVALID = Object.freeze({
  status: "aborted"
});
var DIRTY = (value) => ({ status: "dirty", value });
var OK = (value) => ({ status: "valid", value });
var isAborted = (x) => x.status === "aborted";
var isDirty = (x) => x.status === "dirty";
var isValid = (x) => x.status === "valid";
var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil2) {
  errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
  errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
  constructor(parent, value, path, key2) {
    this._cachedPath = [];
    this.parent = parent;
    this.data = value;
    this._path = path;
    this._key = key2;
  }
  get path() {
    if (!this._cachedPath.length) {
      if (Array.isArray(this._key)) {
        this._cachedPath.push(...this._path, ...this._key);
      } else {
        this._cachedPath.push(...this._path, this._key);
      }
    }
    return this._cachedPath;
  }
};
var handleResult = (ctx, result) => {
  if (isValid(result)) {
    return { success: true, data: result.value };
  } else {
    if (!ctx.common.issues.length) {
      throw new Error("Validation failed but no issues detected.");
    }
    return {
      success: false,
      get error() {
        if (this._error)
          return this._error;
        const error = new ZodError(ctx.common.issues);
        this._error = error;
        return this._error;
      }
    };
  }
};
function processCreateParams(params) {
  if (!params)
    return {};
  const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
  if (errorMap2 && (invalid_type_error || required_error)) {
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  }
  if (errorMap2)
    return { errorMap: errorMap2, description };
  const customMap = (iss, ctx) => {
    const { message } = params;
    if (iss.code === "invalid_enum_value") {
      return { message: message ?? ctx.defaultError };
    }
    if (typeof ctx.data === "undefined") {
      return { message: message ?? required_error ?? ctx.defaultError };
    }
    if (iss.code !== "invalid_type")
      return { message: ctx.defaultError };
    return { message: message ?? invalid_type_error ?? ctx.defaultError };
  };
  return { errorMap: customMap, description };
}
var ZodType = class {
  get description() {
    return this._def.description;
  }
  _getType(input) {
    return getParsedType(input.data);
  }
  _getOrReturnCtx(input, ctx) {
    return ctx || {
      common: input.parent.common,
      data: input.data,
      parsedType: getParsedType(input.data),
      schemaErrorMap: this._def.errorMap,
      path: input.path,
      parent: input.parent
    };
  }
  _processInputParams(input) {
    return {
      status: new ParseStatus(),
      ctx: {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      }
    };
  }
  _parseSync(input) {
    const result = this._parse(input);
    if (isAsync(result)) {
      throw new Error("Synchronous parse encountered promise.");
    }
    return result;
  }
  _parseAsync(input) {
    const result = this._parse(input);
    return Promise.resolve(result);
  }
  parse(data, params) {
    const result = this.safeParse(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  safeParse(data, params) {
    const ctx = {
      common: {
        issues: [],
        async: params?.async ?? false,
        contextualErrorMap: params?.errorMap
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const result = this._parseSync({ data, path: ctx.path, parent: ctx });
    return handleResult(ctx, result);
  }
  "~validate"(data) {
    const ctx = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    if (!this["~standard"].async) {
      try {
        const result = this._parseSync({ data, path: [], parent: ctx });
        return isValid(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        };
      } catch (err) {
        if (err?.message?.toLowerCase()?.includes("encountered")) {
          this["~standard"].async = true;
        }
        ctx.common = {
          issues: [],
          async: true
        };
      }
    }
    return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
      value: result.value
    } : {
      issues: ctx.common.issues
    });
  }
  async parseAsync(data, params) {
    const result = await this.safeParseAsync(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  async safeParseAsync(data, params) {
    const ctx = {
      common: {
        issues: [],
        contextualErrorMap: params?.errorMap,
        async: true
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
    const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
    return handleResult(ctx, result);
  }
  refine(check, message) {
    const getIssueProperties = (val) => {
      if (typeof message === "string" || typeof message === "undefined") {
        return { message };
      } else if (typeof message === "function") {
        return message(val);
      } else {
        return message;
      }
    };
    return this._refinement((val, ctx) => {
      const result = check(val);
      const setError = () => ctx.addIssue({
        code: ZodIssueCode.custom,
        ...getIssueProperties(val)
      });
      if (typeof Promise !== "undefined" && result instanceof Promise) {
        return result.then((data) => {
          if (!data) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      if (!result) {
        setError();
        return false;
      } else {
        return true;
      }
    });
  }
  refinement(check, refinementData) {
    return this._refinement((val, ctx) => {
      if (!check(val)) {
        ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
        return false;
      } else {
        return true;
      }
    });
  }
  _refinement(refinement) {
    return new ZodEffects({
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "refinement", refinement }
    });
  }
  superRefine(refinement) {
    return this._refinement(refinement);
  }
  constructor(def) {
    this.spa = this.safeParseAsync;
    this._def = def;
    this.parse = this.parse.bind(this);
    this.safeParse = this.safeParse.bind(this);
    this.parseAsync = this.parseAsync.bind(this);
    this.safeParseAsync = this.safeParseAsync.bind(this);
    this.spa = this.spa.bind(this);
    this.refine = this.refine.bind(this);
    this.refinement = this.refinement.bind(this);
    this.superRefine = this.superRefine.bind(this);
    this.optional = this.optional.bind(this);
    this.nullable = this.nullable.bind(this);
    this.nullish = this.nullish.bind(this);
    this.array = this.array.bind(this);
    this.promise = this.promise.bind(this);
    this.or = this.or.bind(this);
    this.and = this.and.bind(this);
    this.transform = this.transform.bind(this);
    this.brand = this.brand.bind(this);
    this.default = this.default.bind(this);
    this.catch = this.catch.bind(this);
    this.describe = this.describe.bind(this);
    this.pipe = this.pipe.bind(this);
    this.readonly = this.readonly.bind(this);
    this.isNullable = this.isNullable.bind(this);
    this.isOptional = this.isOptional.bind(this);
    this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: (data) => this["~validate"](data)
    };
  }
  optional() {
    return ZodOptional.create(this, this._def);
  }
  nullable() {
    return ZodNullable.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return ZodArray.create(this);
  }
  promise() {
    return ZodPromise.create(this, this._def);
  }
  or(option) {
    return ZodUnion.create([this, option], this._def);
  }
  and(incoming) {
    return ZodIntersection.create(this, incoming, this._def);
  }
  transform(transform) {
    return new ZodEffects({
      ...processCreateParams(this._def),
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "transform", transform }
    });
  }
  default(def) {
    const defaultValueFunc = typeof def === "function" ? def : () => def;
    return new ZodDefault({
      ...processCreateParams(this._def),
      innerType: this,
      defaultValue: defaultValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodDefault
    });
  }
  brand() {
    return new ZodBranded({
      typeName: ZodFirstPartyTypeKind.ZodBranded,
      type: this,
      ...processCreateParams(this._def)
    });
  }
  catch(def) {
    const catchValueFunc = typeof def === "function" ? def : () => def;
    return new ZodCatch({
      ...processCreateParams(this._def),
      innerType: this,
      catchValue: catchValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodCatch
    });
  }
  describe(description) {
    const This = this.constructor;
    return new This({
      ...this._def,
      description
    });
  }
  pipe(target) {
    return ZodPipeline.create(this, target);
  }
  readonly() {
    return ZodReadonly.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
};
var cuidRegex = /^c[^\s-]{8,}$/i;
var cuid2Regex = /^[0-9a-z]+$/;
var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
var nanoidRegex = /^[a-z0-9_-]{21}$/i;
var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
var emojiRegex;
var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
var dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
  let secondsRegexSource = `[0-5]\\d`;
  if (args.precision) {
    secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
  } else if (args.precision == null) {
    secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
  }
  const secondsQuantifier = args.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
  return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
  let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
  const opts = [];
  opts.push(args.local ? `Z?` : `Z`);
  if (args.offset)
    opts.push(`([+-]\\d{2}:?\\d{2})`);
  regex = `${regex}(${opts.join("|")})`;
  return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
  if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
    return true;
  }
  return false;
}
function isValidJWT(jwt, alg) {
  if (!jwtRegex.test(jwt))
    return false;
  try {
    const [header] = jwt.split(".");
    if (!header)
      return false;
    const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
    const decoded = JSON.parse(atob(base64));
    if (typeof decoded !== "object" || decoded === null)
      return false;
    if ("typ" in decoded && decoded?.typ !== "JWT")
      return false;
    if (!decoded.alg)
      return false;
    if (alg && decoded.alg !== alg)
      return false;
    return true;
  } catch {
    return false;
  }
}
function isValidCidr(ip, version) {
  if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
    return true;
  }
  return false;
}
var ZodString = class _ZodString extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = String(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.string) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.string,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.length < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.length > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "length") {
        const tooBig = input.data.length > check.value;
        const tooSmall = input.data.length < check.value;
        if (tooBig || tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          if (tooBig) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          } else if (tooSmall) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          }
          status.dirty();
        }
      } else if (check.kind === "email") {
        if (!emailRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "email",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "emoji") {
        if (!emojiRegex) {
          emojiRegex = new RegExp(_emojiRegex, "u");
        }
        if (!emojiRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "emoji",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "uuid") {
        if (!uuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "uuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "nanoid") {
        if (!nanoidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "nanoid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid") {
        if (!cuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid2") {
        if (!cuid2Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid2",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ulid") {
        if (!ulidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ulid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "url") {
        try {
          new URL(input.data);
        } catch {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "regex") {
        check.regex.lastIndex = 0;
        const testResult = check.regex.test(input.data);
        if (!testResult) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "regex",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "trim") {
        input.data = input.data.trim();
      } else if (check.kind === "includes") {
        if (!input.data.includes(check.value, check.position)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { includes: check.value, position: check.position },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "toLowerCase") {
        input.data = input.data.toLowerCase();
      } else if (check.kind === "toUpperCase") {
        input.data = input.data.toUpperCase();
      } else if (check.kind === "startsWith") {
        if (!input.data.startsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { startsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "endsWith") {
        if (!input.data.endsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { endsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "datetime") {
        const regex = datetimeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "datetime",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "date") {
        const regex = dateRegex;
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "date",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "time") {
        const regex = timeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "time",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "duration") {
        if (!durationRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "duration",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ip") {
        if (!isValidIP(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ip",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "jwt") {
        if (!isValidJWT(input.data, check.alg)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "jwt",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cidr") {
        if (!isValidCidr(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cidr",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64") {
        if (!base64Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64url") {
        if (!base64urlRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _regex(regex, validation, message) {
    return this.refinement((data) => regex.test(data), {
      validation,
      code: ZodIssueCode.invalid_string,
      ...errorUtil.errToObj(message)
    });
  }
  _addCheck(check) {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  email(message) {
    return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
  }
  url(message) {
    return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
  }
  emoji(message) {
    return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
  }
  uuid(message) {
    return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
  }
  nanoid(message) {
    return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
  }
  cuid(message) {
    return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
  }
  cuid2(message) {
    return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
  }
  ulid(message) {
    return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
  }
  base64(message) {
    return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
  }
  base64url(message) {
    return this._addCheck({
      kind: "base64url",
      ...errorUtil.errToObj(message)
    });
  }
  jwt(options) {
    return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
  }
  ip(options) {
    return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
  }
  cidr(options) {
    return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
  }
  datetime(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "datetime",
        precision: null,
        offset: false,
        local: false,
        message: options
      });
    }
    return this._addCheck({
      kind: "datetime",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      offset: options?.offset ?? false,
      local: options?.local ?? false,
      ...errorUtil.errToObj(options?.message)
    });
  }
  date(message) {
    return this._addCheck({ kind: "date", message });
  }
  time(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "time",
        precision: null,
        message: options
      });
    }
    return this._addCheck({
      kind: "time",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      ...errorUtil.errToObj(options?.message)
    });
  }
  duration(message) {
    return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
  }
  regex(regex, message) {
    return this._addCheck({
      kind: "regex",
      regex,
      ...errorUtil.errToObj(message)
    });
  }
  includes(value, options) {
    return this._addCheck({
      kind: "includes",
      value,
      position: options?.position,
      ...errorUtil.errToObj(options?.message)
    });
  }
  startsWith(value, message) {
    return this._addCheck({
      kind: "startsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  endsWith(value, message) {
    return this._addCheck({
      kind: "endsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  min(minLength, message) {
    return this._addCheck({
      kind: "min",
      value: minLength,
      ...errorUtil.errToObj(message)
    });
  }
  max(maxLength, message) {
    return this._addCheck({
      kind: "max",
      value: maxLength,
      ...errorUtil.errToObj(message)
    });
  }
  length(len, message) {
    return this._addCheck({
      kind: "length",
      value: len,
      ...errorUtil.errToObj(message)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(message) {
    return this.min(1, errorUtil.errToObj(message));
  }
  trim() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((ch) => ch.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((ch) => ch.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((ch) => ch.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((ch) => ch.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((ch) => ch.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((ch) => ch.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((ch) => ch.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((ch) => ch.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((ch) => ch.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((ch) => ch.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((ch) => ch.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((ch) => ch.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((ch) => ch.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((ch) => ch.kind === "base64url");
  }
  get minLength() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxLength() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodString.create = (params) => {
  return new ZodString({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodString,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepDecCount = (step.toString().split(".")[1] || "").length;
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
var ZodNumber = class _ZodNumber extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
    this.step = this.multipleOf;
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = Number(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.number) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.number,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "int") {
        if (!util.isInteger(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: "integer",
            received: "float",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (floatSafeRemainder(input.data, check.value) !== 0) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "finite") {
        if (!Number.isFinite(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_finite,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodNumber({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodNumber({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  int(message) {
    return this._addCheck({
      kind: "int",
      message: errorUtil.toString(message)
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  finite(message) {
    return this._addCheck({
      kind: "finite",
      message: errorUtil.toString(message)
    });
  }
  safe(message) {
    return this._addCheck({
      kind: "min",
      inclusive: true,
      value: Number.MIN_SAFE_INTEGER,
      message: errorUtil.toString(message)
    })._addCheck({
      kind: "max",
      inclusive: true,
      value: Number.MAX_SAFE_INTEGER,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
  get isInt() {
    return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
  }
  get isFinite() {
    let max = null;
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
        return true;
      } else if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      } else if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return Number.isFinite(min) && Number.isFinite(max);
  }
};
ZodNumber.create = (params) => {
  return new ZodNumber({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodNumber,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodBigInt = class _ZodBigInt extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
  }
  _parse(input) {
    if (this._def.coerce) {
      try {
        input.data = BigInt(input.data);
      } catch {
        return this._getInvalidInput(input);
      }
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.bigint) {
      return this._getInvalidInput(input);
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            type: "bigint",
            minimum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            type: "bigint",
            maximum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (input.data % check.value !== BigInt(0)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _getInvalidInput(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.bigint,
      received: ctx.parsedType
    });
    return INVALID;
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodBigInt({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodBigInt({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodBigInt.create = (params) => {
  return new ZodBigInt({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodBigInt,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
var ZodBoolean = class extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = Boolean(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.boolean) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.boolean,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodBoolean.create = (params) => {
  return new ZodBoolean({
    typeName: ZodFirstPartyTypeKind.ZodBoolean,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodDate = class _ZodDate extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = new Date(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.date) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.date,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    if (Number.isNaN(input.data.getTime())) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_date
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.getTime() < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            message: check.message,
            inclusive: true,
            exact: false,
            minimum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.getTime() > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            message: check.message,
            inclusive: true,
            exact: false,
            maximum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return {
      status: status.value,
      value: new Date(input.data.getTime())
    };
  }
  _addCheck(check) {
    return new _ZodDate({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  min(minDate, message) {
    return this._addCheck({
      kind: "min",
      value: minDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  max(maxDate, message) {
    return this._addCheck({
      kind: "max",
      value: maxDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  get minDate() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min != null ? new Date(min) : null;
  }
  get maxDate() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max != null ? new Date(max) : null;
  }
};
ZodDate.create = (params) => {
  return new ZodDate({
    checks: [],
    coerce: params?.coerce || false,
    typeName: ZodFirstPartyTypeKind.ZodDate,
    ...processCreateParams(params)
  });
};
var ZodSymbol = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.symbol) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.symbol,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodSymbol.create = (params) => {
  return new ZodSymbol({
    typeName: ZodFirstPartyTypeKind.ZodSymbol,
    ...processCreateParams(params)
  });
};
var ZodUndefined = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.undefined,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodUndefined.create = (params) => {
  return new ZodUndefined({
    typeName: ZodFirstPartyTypeKind.ZodUndefined,
    ...processCreateParams(params)
  });
};
var ZodNull = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.null) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.null,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodNull.create = (params) => {
  return new ZodNull({
    typeName: ZodFirstPartyTypeKind.ZodNull,
    ...processCreateParams(params)
  });
};
var ZodAny = class extends ZodType {
  constructor() {
    super(...arguments);
    this._any = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodAny.create = (params) => {
  return new ZodAny({
    typeName: ZodFirstPartyTypeKind.ZodAny,
    ...processCreateParams(params)
  });
};
var ZodUnknown = class extends ZodType {
  constructor() {
    super(...arguments);
    this._unknown = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodUnknown.create = (params) => {
  return new ZodUnknown({
    typeName: ZodFirstPartyTypeKind.ZodUnknown,
    ...processCreateParams(params)
  });
};
var ZodNever = class extends ZodType {
  _parse(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.never,
      received: ctx.parsedType
    });
    return INVALID;
  }
};
ZodNever.create = (params) => {
  return new ZodNever({
    typeName: ZodFirstPartyTypeKind.ZodNever,
    ...processCreateParams(params)
  });
};
var ZodVoid = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.void,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodVoid.create = (params) => {
  return new ZodVoid({
    typeName: ZodFirstPartyTypeKind.ZodVoid,
    ...processCreateParams(params)
  });
};
var ZodArray = class _ZodArray extends ZodType {
  _parse(input) {
    const { ctx, status } = this._processInputParams(input);
    const def = this._def;
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (def.exactLength !== null) {
      const tooBig = ctx.data.length > def.exactLength.value;
      const tooSmall = ctx.data.length < def.exactLength.value;
      if (tooBig || tooSmall) {
        addIssueToContext(ctx, {
          code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
          minimum: tooSmall ? def.exactLength.value : void 0,
          maximum: tooBig ? def.exactLength.value : void 0,
          type: "array",
          inclusive: true,
          exact: true,
          message: def.exactLength.message
        });
        status.dirty();
      }
    }
    if (def.minLength !== null) {
      if (ctx.data.length < def.minLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.minLength.message
        });
        status.dirty();
      }
    }
    if (def.maxLength !== null) {
      if (ctx.data.length > def.maxLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.maxLength.message
        });
        status.dirty();
      }
    }
    if (ctx.common.async) {
      return Promise.all([...ctx.data].map((item, i) => {
        return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      })).then((result2) => {
        return ParseStatus.mergeArray(status, result2);
      });
    }
    const result = [...ctx.data].map((item, i) => {
      return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
    });
    return ParseStatus.mergeArray(status, result);
  }
  get element() {
    return this._def.type;
  }
  min(minLength, message) {
    return new _ZodArray({
      ...this._def,
      minLength: { value: minLength, message: errorUtil.toString(message) }
    });
  }
  max(maxLength, message) {
    return new _ZodArray({
      ...this._def,
      maxLength: { value: maxLength, message: errorUtil.toString(message) }
    });
  }
  length(len, message) {
    return new _ZodArray({
      ...this._def,
      exactLength: { value: len, message: errorUtil.toString(message) }
    });
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodArray.create = (schema, params) => {
  return new ZodArray({
    type: schema,
    minLength: null,
    maxLength: null,
    exactLength: null,
    typeName: ZodFirstPartyTypeKind.ZodArray,
    ...processCreateParams(params)
  });
};
function deepPartialify(schema) {
  if (schema instanceof ZodObject) {
    const newShape = {};
    for (const key2 in schema.shape) {
      const fieldSchema = schema.shape[key2];
      newShape[key2] = ZodOptional.create(deepPartialify(fieldSchema));
    }
    return new ZodObject({
      ...schema._def,
      shape: () => newShape
    });
  } else if (schema instanceof ZodArray) {
    return new ZodArray({
      ...schema._def,
      type: deepPartialify(schema.element)
    });
  } else if (schema instanceof ZodOptional) {
    return ZodOptional.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodNullable) {
    return ZodNullable.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodTuple) {
    return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
  } else {
    return schema;
  }
}
var ZodObject = class _ZodObject extends ZodType {
  constructor() {
    super(...arguments);
    this._cached = null;
    this.nonstrict = this.passthrough;
    this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const shape = this._def.shape();
    const keys = util.objectKeys(shape);
    this._cached = { shape, keys };
    return this._cached;
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.object) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const { status, ctx } = this._processInputParams(input);
    const { shape, keys: shapeKeys } = this._getCached();
    const extraKeys = [];
    if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
      for (const key2 in ctx.data) {
        if (!shapeKeys.includes(key2)) {
          extraKeys.push(key2);
        }
      }
    }
    const pairs = [];
    for (const key2 of shapeKeys) {
      const keyValidator = shape[key2];
      const value = ctx.data[key2];
      pairs.push({
        key: { status: "valid", value: key2 },
        value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key2)),
        alwaysSet: key2 in ctx.data
      });
    }
    if (this._def.catchall instanceof ZodNever) {
      const unknownKeys = this._def.unknownKeys;
      if (unknownKeys === "passthrough") {
        for (const key2 of extraKeys) {
          pairs.push({
            key: { status: "valid", value: key2 },
            value: { status: "valid", value: ctx.data[key2] }
          });
        }
      } else if (unknownKeys === "strict") {
        if (extraKeys.length > 0) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.unrecognized_keys,
            keys: extraKeys
          });
          status.dirty();
        }
      } else if (unknownKeys === "strip") {
      } else {
        throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
      }
    } else {
      const catchall = this._def.catchall;
      for (const key2 of extraKeys) {
        const value = ctx.data[key2];
        pairs.push({
          key: { status: "valid", value: key2 },
          value: catchall._parse(
            new ParseInputLazyPath(ctx, value, ctx.path, key2)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: key2 in ctx.data
        });
      }
    }
    if (ctx.common.async) {
      return Promise.resolve().then(async () => {
        const syncPairs = [];
        for (const pair of pairs) {
          const key2 = await pair.key;
          const value = await pair.value;
          syncPairs.push({
            key: key2,
            value,
            alwaysSet: pair.alwaysSet
          });
        }
        return syncPairs;
      }).then((syncPairs) => {
        return ParseStatus.mergeObjectSync(status, syncPairs);
      });
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get shape() {
    return this._def.shape();
  }
  strict(message) {
    errorUtil.errToObj;
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strict",
      ...message !== void 0 ? {
        errorMap: (issue, ctx) => {
          const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
          if (issue.code === "unrecognized_keys")
            return {
              message: errorUtil.errToObj(message).message ?? defaultError
            };
          return {
            message: defaultError
          };
        }
      } : {}
    });
  }
  strip() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(augmentation) {
    return new _ZodObject({
      ...this._def,
      shape: () => ({
        ...this._def.shape(),
        ...augmentation
      })
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(merging) {
    const merged = new _ZodObject({
      unknownKeys: merging._def.unknownKeys,
      catchall: merging._def.catchall,
      shape: () => ({
        ...this._def.shape(),
        ...merging._def.shape()
      }),
      typeName: ZodFirstPartyTypeKind.ZodObject
    });
    return merged;
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(key2, schema) {
    return this.augment({ [key2]: schema });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(index) {
    return new _ZodObject({
      ...this._def,
      catchall: index
    });
  }
  pick(mask) {
    const shape = {};
    for (const key2 of util.objectKeys(mask)) {
      if (mask[key2] && this.shape[key2]) {
        shape[key2] = this.shape[key2];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  omit(mask) {
    const shape = {};
    for (const key2 of util.objectKeys(this.shape)) {
      if (!mask[key2]) {
        shape[key2] = this.shape[key2];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return deepPartialify(this);
  }
  partial(mask) {
    const newShape = {};
    for (const key2 of util.objectKeys(this.shape)) {
      const fieldSchema = this.shape[key2];
      if (mask && !mask[key2]) {
        newShape[key2] = fieldSchema;
      } else {
        newShape[key2] = fieldSchema.optional();
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  required(mask) {
    const newShape = {};
    for (const key2 of util.objectKeys(this.shape)) {
      if (mask && !mask[key2]) {
        newShape[key2] = this.shape[key2];
      } else {
        const fieldSchema = this.shape[key2];
        let newField = fieldSchema;
        while (newField instanceof ZodOptional) {
          newField = newField._def.innerType;
        }
        newShape[key2] = newField;
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  keyof() {
    return createZodEnum(util.objectKeys(this.shape));
  }
};
ZodObject.create = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.strictCreate = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strict",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.lazycreate = (shape, params) => {
  return new ZodObject({
    shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
var ZodUnion = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const options = this._def.options;
    function handleResults(results) {
      for (const result of results) {
        if (result.result.status === "valid") {
          return result.result;
        }
      }
      for (const result of results) {
        if (result.result.status === "dirty") {
          ctx.common.issues.push(...result.ctx.common.issues);
          return result.result;
        }
      }
      const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return Promise.all(options.map(async (option) => {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          }),
          ctx: childCtx
        };
      })).then(handleResults);
    } else {
      let dirty = void 0;
      const issues = [];
      for (const option of options) {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        const result = option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: childCtx
        });
        if (result.status === "valid") {
          return result;
        } else if (result.status === "dirty" && !dirty) {
          dirty = { result, ctx: childCtx };
        }
        if (childCtx.common.issues.length) {
          issues.push(childCtx.common.issues);
        }
      }
      if (dirty) {
        ctx.common.issues.push(...dirty.ctx.common.issues);
        return dirty.result;
      }
      const unionErrors = issues.map((issues2) => new ZodError(issues2));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
  }
  get options() {
    return this._def.options;
  }
};
ZodUnion.create = (types, params) => {
  return new ZodUnion({
    options: types,
    typeName: ZodFirstPartyTypeKind.ZodUnion,
    ...processCreateParams(params)
  });
};
var getDiscriminator = (type) => {
  if (type instanceof ZodLazy) {
    return getDiscriminator(type.schema);
  } else if (type instanceof ZodEffects) {
    return getDiscriminator(type.innerType());
  } else if (type instanceof ZodLiteral) {
    return [type.value];
  } else if (type instanceof ZodEnum) {
    return type.options;
  } else if (type instanceof ZodNativeEnum) {
    return util.objectValues(type.enum);
  } else if (type instanceof ZodDefault) {
    return getDiscriminator(type._def.innerType);
  } else if (type instanceof ZodUndefined) {
    return [void 0];
  } else if (type instanceof ZodNull) {
    return [null];
  } else if (type instanceof ZodOptional) {
    return [void 0, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodNullable) {
    return [null, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodBranded) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodReadonly) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodCatch) {
    return getDiscriminator(type._def.innerType);
  } else {
    return [];
  }
};
var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const discriminator = this.discriminator;
    const discriminatorValue = ctx.data[discriminator];
    const option = this.optionsMap.get(discriminatorValue);
    if (!option) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union_discriminator,
        options: Array.from(this.optionsMap.keys()),
        path: [discriminator]
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return option._parseAsync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    } else {
      return option._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    }
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(discriminator, options, params) {
    const optionsMap = /* @__PURE__ */ new Map();
    for (const type of options) {
      const discriminatorValues = getDiscriminator(type.shape[discriminator]);
      if (!discriminatorValues.length) {
        throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
      }
      for (const value of discriminatorValues) {
        if (optionsMap.has(value)) {
          throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
        }
        optionsMap.set(value, type);
      }
    }
    return new _ZodDiscriminatedUnion({
      typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
      discriminator,
      options,
      optionsMap,
      ...processCreateParams(params)
    });
  }
};
function mergeValues(a, b) {
  const aType = getParsedType(a);
  const bType = getParsedType(b);
  if (a === b) {
    return { valid: true, data: a };
  } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
    const bKeys = util.objectKeys(b);
    const sharedKeys = util.objectKeys(a).filter((key2) => bKeys.indexOf(key2) !== -1);
    const newObj = { ...a, ...b };
    for (const key2 of sharedKeys) {
      const sharedValue = mergeValues(a[key2], b[key2]);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newObj[key2] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
    if (a.length !== b.length) {
      return { valid: false };
    }
    const newArray = [];
    for (let index = 0; index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
    return { valid: true, data: a };
  } else {
    return { valid: false };
  }
}
var ZodIntersection = class extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const handleParsed = (parsedLeft, parsedRight) => {
      if (isAborted(parsedLeft) || isAborted(parsedRight)) {
        return INVALID;
      }
      const merged = mergeValues(parsedLeft.value, parsedRight.value);
      if (!merged.valid) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_intersection_types
        });
        return INVALID;
      }
      if (isDirty(parsedLeft) || isDirty(parsedRight)) {
        status.dirty();
      }
      return { status: status.value, value: merged.data };
    };
    if (ctx.common.async) {
      return Promise.all([
        this._def.left._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }),
        this._def.right._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        })
      ]).then(([left, right]) => handleParsed(left, right));
    } else {
      return handleParsed(this._def.left._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }), this._def.right._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }));
    }
  }
};
ZodIntersection.create = (left, right, params) => {
  return new ZodIntersection({
    left,
    right,
    typeName: ZodFirstPartyTypeKind.ZodIntersection,
    ...processCreateParams(params)
  });
};
var ZodTuple = class _ZodTuple extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (ctx.data.length < this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_small,
        minimum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      return INVALID;
    }
    const rest = this._def.rest;
    if (!rest && ctx.data.length > this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_big,
        maximum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      status.dirty();
    }
    const items = [...ctx.data].map((item, itemIndex) => {
      const schema = this._def.items[itemIndex] || this._def.rest;
      if (!schema)
        return null;
      return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
    }).filter((x) => !!x);
    if (ctx.common.async) {
      return Promise.all(items).then((results) => {
        return ParseStatus.mergeArray(status, results);
      });
    } else {
      return ParseStatus.mergeArray(status, items);
    }
  }
  get items() {
    return this._def.items;
  }
  rest(rest) {
    return new _ZodTuple({
      ...this._def,
      rest
    });
  }
};
ZodTuple.create = (schemas, params) => {
  if (!Array.isArray(schemas)) {
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  }
  return new ZodTuple({
    items: schemas,
    typeName: ZodFirstPartyTypeKind.ZodTuple,
    rest: null,
    ...processCreateParams(params)
  });
};
var ZodRecord = class _ZodRecord extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const pairs = [];
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    for (const key2 in ctx.data) {
      pairs.push({
        key: keyType._parse(new ParseInputLazyPath(ctx, key2, ctx.path, key2)),
        value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key2], ctx.path, key2)),
        alwaysSet: key2 in ctx.data
      });
    }
    if (ctx.common.async) {
      return ParseStatus.mergeObjectAsync(status, pairs);
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get element() {
    return this._def.valueType;
  }
  static create(first, second, third) {
    if (second instanceof ZodType) {
      return new _ZodRecord({
        keyType: first,
        valueType: second,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(third)
      });
    }
    return new _ZodRecord({
      keyType: ZodString.create(),
      valueType: first,
      typeName: ZodFirstPartyTypeKind.ZodRecord,
      ...processCreateParams(second)
    });
  }
};
var ZodMap = class extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.map) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.map,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    const pairs = [...ctx.data.entries()].map(([key2, value], index) => {
      return {
        key: keyType._parse(new ParseInputLazyPath(ctx, key2, ctx.path, [index, "key"])),
        value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
      };
    });
    if (ctx.common.async) {
      const finalMap = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const pair of pairs) {
          const key2 = await pair.key;
          const value = await pair.value;
          if (key2.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key2.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key2.value, value.value);
        }
        return { status: status.value, value: finalMap };
      });
    } else {
      const finalMap = /* @__PURE__ */ new Map();
      for (const pair of pairs) {
        const key2 = pair.key;
        const value = pair.value;
        if (key2.status === "aborted" || value.status === "aborted") {
          return INVALID;
        }
        if (key2.status === "dirty" || value.status === "dirty") {
          status.dirty();
        }
        finalMap.set(key2.value, value.value);
      }
      return { status: status.value, value: finalMap };
    }
  }
};
ZodMap.create = (keyType, valueType, params) => {
  return new ZodMap({
    valueType,
    keyType,
    typeName: ZodFirstPartyTypeKind.ZodMap,
    ...processCreateParams(params)
  });
};
var ZodSet = class _ZodSet extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.set) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.set,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const def = this._def;
    if (def.minSize !== null) {
      if (ctx.data.size < def.minSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.minSize.message
        });
        status.dirty();
      }
    }
    if (def.maxSize !== null) {
      if (ctx.data.size > def.maxSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.maxSize.message
        });
        status.dirty();
      }
    }
    const valueType = this._def.valueType;
    function finalizeSet(elements2) {
      const parsedSet = /* @__PURE__ */ new Set();
      for (const element of elements2) {
        if (element.status === "aborted")
          return INVALID;
        if (element.status === "dirty")
          status.dirty();
        parsedSet.add(element.value);
      }
      return { status: status.value, value: parsedSet };
    }
    const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
    if (ctx.common.async) {
      return Promise.all(elements).then((elements2) => finalizeSet(elements2));
    } else {
      return finalizeSet(elements);
    }
  }
  min(minSize, message) {
    return new _ZodSet({
      ...this._def,
      minSize: { value: minSize, message: errorUtil.toString(message) }
    });
  }
  max(maxSize, message) {
    return new _ZodSet({
      ...this._def,
      maxSize: { value: maxSize, message: errorUtil.toString(message) }
    });
  }
  size(size, message) {
    return this.min(size, message).max(size, message);
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodSet.create = (valueType, params) => {
  return new ZodSet({
    valueType,
    minSize: null,
    maxSize: null,
    typeName: ZodFirstPartyTypeKind.ZodSet,
    ...processCreateParams(params)
  });
};
var ZodFunction = class _ZodFunction extends ZodType {
  constructor() {
    super(...arguments);
    this.validate = this.implement;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.function) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.function,
        received: ctx.parsedType
      });
      return INVALID;
    }
    function makeArgsIssue(args, error) {
      return makeIssue({
        data: args,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_arguments,
          argumentsError: error
        }
      });
    }
    function makeReturnsIssue(returns, error) {
      return makeIssue({
        data: returns,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_return_type,
          returnTypeError: error
        }
      });
    }
    const params = { errorMap: ctx.common.contextualErrorMap };
    const fn = ctx.data;
    if (this._def.returns instanceof ZodPromise) {
      const me = this;
      return OK(async function(...args) {
        const error = new ZodError([]);
        const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
          error.addIssue(makeArgsIssue(args, e));
          throw error;
        });
        const result = await Reflect.apply(fn, this, parsedArgs);
        const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
          error.addIssue(makeReturnsIssue(result, e));
          throw error;
        });
        return parsedReturns;
      });
    } else {
      const me = this;
      return OK(function(...args) {
        const parsedArgs = me._def.args.safeParse(args, params);
        if (!parsedArgs.success) {
          throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
        }
        const result = Reflect.apply(fn, this, parsedArgs.data);
        const parsedReturns = me._def.returns.safeParse(result, params);
        if (!parsedReturns.success) {
          throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
        }
        return parsedReturns.data;
      });
    }
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...items) {
    return new _ZodFunction({
      ...this._def,
      args: ZodTuple.create(items).rest(ZodUnknown.create())
    });
  }
  returns(returnType) {
    return new _ZodFunction({
      ...this._def,
      returns: returnType
    });
  }
  implement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  strictImplement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  static create(args, returns, params) {
    return new _ZodFunction({
      args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
      returns: returns || ZodUnknown.create(),
      typeName: ZodFirstPartyTypeKind.ZodFunction,
      ...processCreateParams(params)
    });
  }
};
var ZodLazy = class extends ZodType {
  get schema() {
    return this._def.getter();
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const lazySchema = this._def.getter();
    return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
  }
};
ZodLazy.create = (getter, params) => {
  return new ZodLazy({
    getter,
    typeName: ZodFirstPartyTypeKind.ZodLazy,
    ...processCreateParams(params)
  });
};
var ZodLiteral = class extends ZodType {
  _parse(input) {
    if (input.data !== this._def.value) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_literal,
        expected: this._def.value
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
  get value() {
    return this._def.value;
  }
};
ZodLiteral.create = (value, params) => {
  return new ZodLiteral({
    value,
    typeName: ZodFirstPartyTypeKind.ZodLiteral,
    ...processCreateParams(params)
  });
};
function createZodEnum(values, params) {
  return new ZodEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodEnum,
    ...processCreateParams(params)
  });
}
var ZodEnum = class _ZodEnum extends ZodType {
  _parse(input) {
    if (typeof input.data !== "string") {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(this._def.values);
    }
    if (!this._cache.has(input.data)) {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Values() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  extract(values, newDef = this._def) {
    return _ZodEnum.create(values, {
      ...this._def,
      ...newDef
    });
  }
  exclude(values, newDef = this._def) {
    return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
      ...this._def,
      ...newDef
    });
  }
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
  _parse(input) {
    const nativeEnumValues = util.getValidEnumValues(this._def.values);
    const ctx = this._getOrReturnCtx(input);
    if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(util.getValidEnumValues(this._def.values));
    }
    if (!this._cache.has(input.data)) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get enum() {
    return this._def.values;
  }
};
ZodNativeEnum.create = (values, params) => {
  return new ZodNativeEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
    ...processCreateParams(params)
  });
};
var ZodPromise = class extends ZodType {
  unwrap() {
    return this._def.type;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.promise,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
    return OK(promisified.then((data) => {
      return this._def.type.parseAsync(data, {
        path: ctx.path,
        errorMap: ctx.common.contextualErrorMap
      });
    }));
  }
};
ZodPromise.create = (schema, params) => {
  return new ZodPromise({
    type: schema,
    typeName: ZodFirstPartyTypeKind.ZodPromise,
    ...processCreateParams(params)
  });
};
var ZodEffects = class extends ZodType {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const effect = this._def.effect || null;
    const checkCtx = {
      addIssue: (arg) => {
        addIssueToContext(ctx, arg);
        if (arg.fatal) {
          status.abort();
        } else {
          status.dirty();
        }
      },
      get path() {
        return ctx.path;
      }
    };
    checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
    if (effect.type === "preprocess") {
      const processed = effect.transform(ctx.data, checkCtx);
      if (ctx.common.async) {
        return Promise.resolve(processed).then(async (processed2) => {
          if (status.value === "aborted")
            return INVALID;
          const result = await this._def.schema._parseAsync({
            data: processed2,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        });
      } else {
        if (status.value === "aborted")
          return INVALID;
        const result = this._def.schema._parseSync({
          data: processed,
          path: ctx.path,
          parent: ctx
        });
        if (result.status === "aborted")
          return INVALID;
        if (result.status === "dirty")
          return DIRTY(result.value);
        if (status.value === "dirty")
          return DIRTY(result.value);
        return result;
      }
    }
    if (effect.type === "refinement") {
      const executeRefinement = (acc) => {
        const result = effect.refinement(acc, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(result);
        }
        if (result instanceof Promise) {
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        }
        return acc;
      };
      if (ctx.common.async === false) {
        const inner = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inner.status === "aborted")
          return INVALID;
        if (inner.status === "dirty")
          status.dirty();
        executeRefinement(inner.value);
        return { status: status.value, value: inner.value };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          return executeRefinement(inner.value).then(() => {
            return { status: status.value, value: inner.value };
          });
        });
      }
    }
    if (effect.type === "transform") {
      if (ctx.common.async === false) {
        const base2 = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (!isValid(base2))
          return INVALID;
        const result = effect.transform(base2.value, checkCtx);
        if (result instanceof Promise) {
          throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
        }
        return { status: status.value, value: result };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base2) => {
          if (!isValid(base2))
            return INVALID;
          return Promise.resolve(effect.transform(base2.value, checkCtx)).then((result) => ({
            status: status.value,
            value: result
          }));
        });
      }
    }
    util.assertNever(effect);
  }
};
ZodEffects.create = (schema, effect, params) => {
  return new ZodEffects({
    schema,
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    effect,
    ...processCreateParams(params)
  });
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
  return new ZodEffects({
    schema,
    effect: { type: "preprocess", transform: preprocess },
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    ...processCreateParams(params)
  });
};
var ZodOptional = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.undefined) {
      return OK(void 0);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodOptional.create = (type, params) => {
  return new ZodOptional({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodOptional,
    ...processCreateParams(params)
  });
};
var ZodNullable = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.null) {
      return OK(null);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodNullable.create = (type, params) => {
  return new ZodNullable({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodNullable,
    ...processCreateParams(params)
  });
};
var ZodDefault = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    let data = ctx.data;
    if (ctx.parsedType === ZodParsedType.undefined) {
      data = this._def.defaultValue();
    }
    return this._def.innerType._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
};
ZodDefault.create = (type, params) => {
  return new ZodDefault({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodDefault,
    defaultValue: typeof params.default === "function" ? params.default : () => params.default,
    ...processCreateParams(params)
  });
};
var ZodCatch = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const newCtx = {
      ...ctx,
      common: {
        ...ctx.common,
        issues: []
      }
    };
    const result = this._def.innerType._parse({
      data: newCtx.data,
      path: newCtx.path,
      parent: {
        ...newCtx
      }
    });
    if (isAsync(result)) {
      return result.then((result2) => {
        return {
          status: "valid",
          value: result2.status === "valid" ? result2.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      });
    } else {
      return {
        status: "valid",
        value: result.status === "valid" ? result.value : this._def.catchValue({
          get error() {
            return new ZodError(newCtx.common.issues);
          },
          input: newCtx.data
        })
      };
    }
  }
  removeCatch() {
    return this._def.innerType;
  }
};
ZodCatch.create = (type, params) => {
  return new ZodCatch({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodCatch,
    catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
    ...processCreateParams(params)
  });
};
var ZodNaN = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.nan) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.nan,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
};
ZodNaN.create = (params) => {
  return new ZodNaN({
    typeName: ZodFirstPartyTypeKind.ZodNaN,
    ...processCreateParams(params)
  });
};
var BRAND = Symbol("zod_brand");
var ZodBranded = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const data = ctx.data;
    return this._def.type._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  unwrap() {
    return this._def.type;
  }
};
var ZodPipeline = class _ZodPipeline extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.common.async) {
      const handleAsync = async () => {
        const inResult = await this._def.in._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return DIRTY(inResult.value);
        } else {
          return this._def.out._parseAsync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      };
      return handleAsync();
    } else {
      const inResult = this._def.in._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
      if (inResult.status === "aborted")
        return INVALID;
      if (inResult.status === "dirty") {
        status.dirty();
        return {
          status: "dirty",
          value: inResult.value
        };
      } else {
        return this._def.out._parseSync({
          data: inResult.value,
          path: ctx.path,
          parent: ctx
        });
      }
    }
  }
  static create(a, b) {
    return new _ZodPipeline({
      in: a,
      out: b,
      typeName: ZodFirstPartyTypeKind.ZodPipeline
    });
  }
};
var ZodReadonly = class extends ZodType {
  _parse(input) {
    const result = this._def.innerType._parse(input);
    const freeze = (data) => {
      if (isValid(data)) {
        data.value = Object.freeze(data.value);
      }
      return data;
    };
    return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodReadonly.create = (type, params) => {
  return new ZodReadonly({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodReadonly,
    ...processCreateParams(params)
  });
};
function cleanParams(params, data) {
  const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
  const p2 = typeof p === "string" ? { message: p } : p;
  return p2;
}
function custom(check, _params = {}, fatal) {
  if (check)
    return ZodAny.create().superRefine((data, ctx) => {
      const r = check(data);
      if (r instanceof Promise) {
        return r.then((r2) => {
          if (!r2) {
            const params = cleanParams(_params, data);
            const _fatal = params.fatal ?? fatal ?? true;
            ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
          }
        });
      }
      if (!r) {
        const params = cleanParams(_params, data);
        const _fatal = params.fatal ?? fatal ?? true;
        ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
      }
      return;
    });
  return ZodAny.create();
}
var late = {
  object: ZodObject.lazycreate
};
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind2) {
  ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
  ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
  ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
  ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
  ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
  ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
  ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
  ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
  ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
  ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
  ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
  ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
  ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
  ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
  ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
  ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
  ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
  ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
  ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
  ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
  ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
  ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
  ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
  ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
  ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
  ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
  ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
  ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
  ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
  ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
  ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
  ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
  ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
  ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
  ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
  ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
var instanceOfType = (cls, params = {
  message: `Input not instance of ${cls.name}`
}) => custom((data) => data instanceof cls, params);
var stringType = ZodString.create;
var numberType = ZodNumber.create;
var nanType = ZodNaN.create;
var bigIntType = ZodBigInt.create;
var booleanType = ZodBoolean.create;
var dateType = ZodDate.create;
var symbolType = ZodSymbol.create;
var undefinedType = ZodUndefined.create;
var nullType = ZodNull.create;
var anyType = ZodAny.create;
var unknownType = ZodUnknown.create;
var neverType = ZodNever.create;
var voidType = ZodVoid.create;
var arrayType = ZodArray.create;
var objectType = ZodObject.create;
var strictObjectType = ZodObject.strictCreate;
var unionType = ZodUnion.create;
var discriminatedUnionType = ZodDiscriminatedUnion.create;
var intersectionType = ZodIntersection.create;
var tupleType = ZodTuple.create;
var recordType = ZodRecord.create;
var mapType = ZodMap.create;
var setType = ZodSet.create;
var functionType = ZodFunction.create;
var lazyType = ZodLazy.create;
var literalType = ZodLiteral.create;
var enumType = ZodEnum.create;
var nativeEnumType = ZodNativeEnum.create;
var promiseType = ZodPromise.create;
var effectsType = ZodEffects.create;
var optionalType = ZodOptional.create;
var nullableType = ZodNullable.create;
var preprocessType = ZodEffects.createWithPreprocess;
var pipelineType = ZodPipeline.create;
var ostring = () => stringType().optional();
var onumber = () => numberType().optional();
var oboolean = () => booleanType().optional();
var coerce = {
  string: ((arg) => ZodString.create({ ...arg, coerce: true })),
  number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
  boolean: ((arg) => ZodBoolean.create({
    ...arg,
    coerce: true
  })),
  bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
  date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
};
var NEVER = INVALID;

// lib/cms/hero-slider.ts
var base = "/assets/clubmuur-brush-v25";
var HERO_BACKGROUND_PRESETS = [
  { id: "houtrust", label: "Onze kantine op Houtrust", src: `${base}/houtrust-wide-1672.webp` },
  { id: "de-wijk", label: "Het Meeuwenhof en de kerk", src: `${base}/de-wijk-wide-1672.webp` },
  { id: "aan-zee", label: "Het havenhoofd en de wijk", src: `${base}/aan-zee-wide-1672.webp` }
];
function createDefaultHeroSlider() {
  return { slides: HERO_BACKGROUND_PRESETS.map((preset) => ({ id: `background-${preset.id}`, source: "builtin", sourceId: preset.id, label: preset.label, enabled: true, focusX: 50, focusY: 50 })), autoplay: true, intervalMs: 1e4, transition: "fade", transitionMs: 1600, zoom: "subtle", parallax: true, showIndicators: true };
}
var identifier = external_exports.string().trim().min(1, "Een afbeelding mist een identifier.").max(200);
var percent = external_exports.number().finite().min(0).max(100);
var slideSchema = external_exports.object({
  id: identifier,
  source: external_exports.enum(["builtin", "media"]),
  sourceId: identifier,
  label: external_exports.string().trim().min(1, "Geef iedere afbeelding een naam.").max(160),
  enabled: external_exports.boolean(),
  focusX: percent,
  focusY: percent
}).strict().superRefine((slide, context) => {
  if (slide.source === "builtin" && !HERO_BACKGROUND_PRESETS.some((preset) => preset.id === slide.sourceId)) context.addIssue({ code: "custom", path: ["sourceId"], message: "Deze standaardachtergrond bestaat niet." });
});
var heroSliderSchema = external_exports.object({
  slides: external_exports.array(slideSchema).max(20, "Gebruik maximaal 20 achtergrondafbeeldingen."),
  autoplay: external_exports.boolean(),
  intervalMs: external_exports.number().int().min(4e3).max(6e4),
  transition: external_exports.enum(["fade", "none"]),
  transitionMs: external_exports.number().int().min(0).max(3e3),
  zoom: external_exports.enum(["none", "subtle", "cinematic"]),
  parallax: external_exports.boolean(),
  showIndicators: external_exports.boolean()
}).strict().superRefine((slider2, context) => {
  if (slider2.transitionMs >= slider2.intervalMs) context.addIssue({ code: "custom", path: ["transitionMs"], message: "De overgang moet korter zijn dan de weergavetijd." });
  if (new Set(slider2.slides.map((slide) => slide.id)).size !== slider2.slides.length) context.addIssue({ code: "custom", path: ["slides"], message: "Iedere dia moet een unieke identifier hebben." });
  if (new Set(slider2.slides.map((slide) => `${slide.source}:${slide.sourceId}`)).size !== slider2.slides.length) context.addIssue({ code: "custom", path: ["slides"], message: "Een afbeelding staat meer dan \xE9\xE9n keer in de slider." });
});

// lib/cms/public-adapters.ts
function cmsArticlesForSite(state2, contentType = "news") {
  return state2.articles.filter((article) => !article.deletedAt && article.live && (article.live.contentType || "news") === contentType).map((article) => {
    const live = article.live;
    const cover = state2.media.find((media2) => media2.id === live.coverId && media2.published && !media2.deletedAt);
    const text3 = docText(live.body);
    const date = new Date(live.publishedAt);
    return { id: article.id, publishedAt: live.publishedAt, featured: live.featured, featuredUntil: live.featuredUntil, title: live.title, category: live.category, intro: live.intro, image: cover?.src || "/assets/crest-close.webp", date: Number.isNaN(date.getTime()) ? "" : new Intl.DateTimeFormat("nl-NL", { day: "numeric", month: "long", year: "numeric" }).format(date), minutes: Math.max(1, Math.ceil(text3.trim().split(/\s+/).length / 200)), body: text3.split("\n").filter(Boolean) };
  });
}

// lib/clubmuur-config.ts
var heroPages = [{ value: "", label: "Homepage" }, ...["nieuws", "verhalen", "teams", "wedstrijden", ...clubContentPaths.filter((path) => !["media/club-tv", "wedstrijden/oefenwedstrijd"].includes(path))].map((value) => ({ value, label: clubContentTitles[value] }))];
var defaultHeroCards = [
  { id: "top-left", kind: "news", target: "latest", title: "Laatste nieuws.", kicker: "VAN DE CLUB", description: "", image: "/assets/clubmuur-portrait.webp", layout: "photo" },
  { id: "top-right", kind: "match", target: "next", title: "Volgende wedstrijd", kicker: "THUIS", description: "", image: "/assets/team.png", layout: "photo" },
  { id: "bottom-left", kind: "page", target: "club/vrijwilligers", title: "De kracht van\nvrijwilligers", kicker: "ONZE MENSEN", description: "", image: "/assets/team.png", layout: "photo" },
  { id: "bottom-right", kind: "team", target: "walking", title: "Walking\nFootball", kicker: "EEN LEVEN LANG", description: "Voetbalplezier\nvoor iedereen", image: "/assets/clubmuur-walking.jpg", layout: "split" }
];

// lib/sportlink-assignments.ts
var text = (value) => typeof value === "string" ? value.trim() : typeof value === "number" ? String(value) : "";
function sportlinkAssignmentFields(value) {
  return { field: text(value.veld) || text(value.veldnaam), changingRooms: { home: text(value.kleedkamerthuisteam), away: text(value.kleedkameruitteam), official: text(value.kleedkamerscheidsrechter) } };
}

// lib/sportlink-normalize.ts
var ZONE = "Europe/Amsterdam";
var text2 = (value) => typeof value === "string" ? value.trim() : typeof value === "number" && Number.isFinite(value) ? String(value) : "";
var raw = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : {};
var key = (value) => text2(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[.]/g, "").replace(/\s+/g, " ").trim();
var truth = (value) => value === true || ["true", "ja", "1"].includes(key(value));
var integer = (value) => Number.isFinite(Number(value)) ? Math.trunc(Number(value)) : 0;
var validTeamCode = (value) => /^\d+$/.test(text2(value)) && Number(value) > 0 ? text2(value) : "";
var sideKey = (club, name) => `${club}:${key(name)}`;
var completed = (status) => ["uitgespeeld", "gespeeld", "eindstand", "beeindigd", "afgelopen", "finished", "completed", "na verlenging", "na strafschoppen"].includes(key(status));
function localDate(date) {
  const fields = new Intl.DateTimeFormat("en-CA", { timeZone: ZONE, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(date);
  const get = (type) => fields.find((part) => part.type === type)?.value || "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}
function weekKey(kickoff2) {
  const date = /* @__PURE__ */ new Date(`${localDate(new Date(kickoff2))}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() - (date.getUTCDay() + 6) % 7);
  return date.toISOString().slice(0, 10);
}
function dateLabel(date) {
  return new Intl.DateTimeFormat("nl-NL", { day: "numeric", month: "short", timeZone: ZONE }).format(/* @__PURE__ */ new Date(`${date}T12:00:00Z`));
}
function kickoff(row2) {
  const value = text2(row2.wedstrijddatum);
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}.*(?:Z|[+-]\d{2}:?\d{2})$/.test(value)) return null;
  const time = new Date(value.replace(/([+-]\d{2})(\d{2})$/, "$1:$2"));
  return Number.isNaN(time.getTime()) ? null : time.toISOString();
}
function score(row2, status) {
  if (!completed(status)) return null;
  const value = text2(row2.uitslag) || text2(row2["uitslag-regulier"]);
  const pair = value.match(/^(\d{1,3})\s*[-–:]\s*(\d{1,3})(?:\s*\([^)]*\))?$/);
  return pair ? [Number(pair[1]), Number(pair[2])] : null;
}
function normalizeTeams(input) {
  const teams2 = /* @__PURE__ */ new Map();
  for (const value of input) {
    const row2 = raw(value);
    const teamCode = text2(row2.teamcode);
    const localTeamCode = text2(row2.lokaleteamcode) || "-1";
    const name = text2(row2.teamnaam);
    if (!name || !validTeamCode(teamCode) && !validTeamCode(localTeamCode)) continue;
    const id = `${teamCode}:${localTeamCode}`;
    let team = teams2.get(id);
    if (!team) {
      team = { id, teamCode, localTeamCode, name, category: text2(row2.leeftijdscategorie), gender: text2(row2.geslacht), sport: text2(row2.spelsoort), day: text2(row2.speeldag), competitions: [] };
      teams2.set(id, team);
    }
    const competitionId = text2(row2.poulecode);
    if (validTeamCode(competitionId) && !team.competitions.some((item) => item.id === competitionId)) {
      team.competitions.push({ id: competitionId, label: text2(row2.klassepoule) || text2(row2.competitienaam), type: key(row2.competitiesoort) });
    }
  }
  return [...teams2.values()];
}
function normalizeSportlink(input, now = /* @__PURE__ */ new Date()) {
  const teams2 = normalizeTeams(input.teams);
  const firstTeam = teams2.find((team) => /^duindorp(?: sv)? 1$/.test(key(team.name)) && (!team.gender || key(team.gender) === "man")) || null;
  const competition = firstTeam?.competitions.find((item) => item.type === "regulier") || null;
  const ownCodes = new Set(teams2.map((team) => validTeamCode(team.teamCode)).filter(Boolean));
  const leagueRows = [...input.leagueResults, ...input.leagueFixtures].map(raw);
  const allRawMatches = [...leagueRows, ...input.clubResults.map(raw), ...input.clubFixtures.map(raw)];
  const ownStanding = input.standings.map(raw).find((row2) => truth(row2.eigenteam));
  let ownClubCode = text2(ownStanding?.clubrelatiecode);
  if (!ownClubCode) {
    for (const row2 of allRawMatches) {
      for (const prefix of ["thuis", "uit"]) {
        const code = validTeamCode(row2[`${prefix}teamid`]);
        if (code && ownCodes.has(code) && text2(row2[`${prefix}teamclubrelatiecode`])) ownClubCode = text2(row2[`${prefix}teamclubrelatiecode`]);
      }
      if (ownClubCode) break;
    }
  }
  const sideIds = /* @__PURE__ */ new Map();
  for (const row2 of allRawMatches) {
    for (const prefix of ["thuis", "uit"]) {
      const id = validTeamCode(row2[`${prefix}teamid`]);
      if (id) sideIds.set(sideKey(text2(row2[`${prefix}teamclubrelatiecode`]), text2(row2[`${prefix}team`])), id);
    }
  }
  const side = (name, clubCode, id, explicitOwn = false) => {
    const own = explicitOwn || !!clubCode && clubCode === ownClubCode || !!validTeamCode(id) && ownCodes.has(id) || /^duindorp(?: sv)?(?: |$)/.test(key(name));
    return {
      id: validTeamCode(id) || sideIds.get(sideKey(clubCode, name)) || sideKey(clubCode, name),
      name,
      clubCode,
      own,
      logoUrl: own ? "/assets/logo.png" : clubCode ? `https://logoapi.voetbal.nl/logo.php?clubcode=${encodeURIComponent(clubCode)}` : null
    };
  };
  const leagueMatchIds = new Set(leagueRows.map((row2) => text2(row2.wedstrijdcode)));
  const match = (row2, league = false) => {
    const id = text2(row2.wedstrijdcode);
    const date = kickoff(row2);
    const homeName = text2(row2.thuisteam);
    const awayName = text2(row2.uitteam);
    if (!id || !date || !homeName || !awayName) return null;
    const status = text2(row2.status);
    const goals = score(row2, status);
    const inLeague = league || leagueMatchIds.has(id);
    return {
      id,
      kickoff: date,
      home: side(homeName, text2(row2.thuisteamclubrelatiecode), text2(row2.thuisteamid)),
      away: side(awayName, text2(row2.uitteamclubrelatiecode), text2(row2.uitteamid)),
      homeScore: goals?.[0] ?? null,
      awayScore: goals?.[1] ?? null,
      scoreLabel: goals ? `${goals[0]} \u2013 ${goals[1]}` : null,
      status,
      venue: text2(row2.accommodatie),
      ...sportlinkAssignmentFields(row2),
      competitionId: inLeague ? competition?.id || "" : text2(row2.poulecode),
      competitionLabel: inLeague ? competition?.label || "" : text2(row2.klassepoule) || text2(row2.competitienaam) || text2(row2.competitie)
    };
  };
  const matches = (rows, league = false) => {
    const unique = /* @__PURE__ */ new Map();
    for (const row2 of rows) {
      const item = match(raw(row2), league);
      if (item) unique.set(item.id, item);
    }
    return [...unique.values()].sort((a, b) => a.kickoff.localeCompare(b.kickoff) || a.id.localeCompare(b.id));
  };
  const leagueResults = competition ? matches(input.leagueResults, true) : [];
  const leagueFixtures = competition ? matches(input.leagueFixtures, true) : [];
  const previous = leagueResults.filter((item) => new Date(item.kickoff).getTime() <= now.getTime());
  const upcoming = leagueFixtures.filter((item) => new Date(item.kickoff).getTime() >= now.getTime() && !completed(item.status));
  const toRound = (items, fallback) => {
    if (!items.length) return { label: fallback, startDate: null, endDate: null, matches: [] };
    const startDate = localDate(new Date(items[0].kickoff));
    const endDate = localDate(new Date(items[items.length - 1].kickoff));
    return { label: startDate === endDate ? dateLabel(startDate) : `${dateLabel(startDate)} \u2013 ${dateLabel(endDate)}`, startDate, endDate, matches: items };
  };
  const pastWeek = previous.length ? weekKey(previous[previous.length - 1].kickoff) : null;
  const nextWeek = upcoming.length ? weekKey(upcoming[0].kickoff) : null;
  const results = matches(input.clubResults);
  const fixtures = matches(input.clubFixtures);
  const formFor = (team) => previous.filter((item) => item.homeScore !== null && item.awayScore !== null && (item.home.id === team.id || item.away.id === team.id)).slice(-5).map((item) => {
    const home = item.home.id === team.id;
    const own = home ? item.homeScore : item.awayScore;
    const opponent = home ? item.awayScore : item.homeScore;
    return own === opponent ? "GL" : own > opponent ? "W" : "V";
  });
  const standings = competition ? input.standings.map(raw).filter((row2) => integer(row2.positie) > 0 && !!text2(row2.teamnaam)).map((row2) => {
    const team = side(text2(row2.teamnaam), text2(row2.clubrelatiecode), text2(row2.teamcode), truth(row2.eigenteam));
    return {
      rank: integer(row2.positie),
      team,
      played: integer(row2.gespeeldewedstrijden),
      won: integer(row2.gewonnen),
      drawn: integer(row2.gelijk),
      lost: integer(row2.verloren),
      goalsFor: integer(row2.doelpuntenvoor),
      goalsAgainst: integer(row2.doelpuntentegen),
      goalDifference: integer(row2.doelsaldo),
      points: integer(row2.punten),
      form: formFor(team)
    };
  }).sort((a, b) => a.rank - b.rank) : [];
  const candidates = new Map([...leagueFixtures, ...fixtures].map((item) => [item.id, item]));
  const nextMatch = firstTeam ? [...candidates.values()].filter((item) => new Date(item.kickoff).getTime() >= now.getTime() && !completed(item.status) && !/afgelast|uitgesteld|vervallen|geannuleerd|cancelled|postponed/i.test(item.status) && (item.home.id === firstTeam.teamCode || item.away.id === firstTeam.teamCode)).sort((a, b) => a.kickoff.localeCompare(b.kickoff))[0] || null : null;
  return {
    updatedAt: now.toISOString(),
    stale: false,
    warning: null,
    teams: teams2,
    firstTeam,
    competition,
    standings,
    previousRound: toRound(previous.filter((item) => weekKey(item.kickoff) === pastWeek), "Nog geen uitslagen"),
    nextRound: toRound(upcoming.filter((item) => weekKey(item.kickoff) === nextWeek), "Programma volgt"),
    nextMatch,
    results,
    fixtures
  };
}

// <stdin>
var import_node_fs = require("node:fs");
var RealDate = Date;
globalThis.Date = class extends RealDate {
  constructor(...args) {
    super(...args.length ? args : [17924904e5]);
  }
  static now() {
    return 17924904e5;
  }
};
var state = createCmsSeed();
var slider = createDefaultHeroSlider();
var media = { id: "fixture-media-background", name: "Vaste clubachtergrond", src: "/assets/clubmuur-brush-v25/de-wijk-wide-1672.webp", alt: "Een vaste blauwe clubachtergrond", caption: "", credit: "", folderId: "", teamId: "", season: "2026\u20132027", published: true, featured: false, order: 0, focusX: 50, focusY: 50, createdAt: "2026-10-20T10:00:00Z" };
state.media.push(media);
state.appearance = { ...state.appearance, hero: defaultHeroCards, heroPhotos: ["01-trots"], heroSlider: slider };
var sportlink = normalizeSportlink({ teams: [{ teamcode: 1, lokaleteamcode: -1, teamnaam: "Duindorp sv 1" }], standings: [], leagueResults: [], leagueFixtures: [], clubResults: [], clubFixtures: [{ wedstrijdcode: 42, wedstrijddatum: "2026-10-24T14:30:00+0200", thuisteamid: 1, thuisteam: "Duindorp SV 1", thuisteamclubrelatiecode: "BBGV51U", uitteamid: 2, uitteam: "Die Haghe 1", uitteamclubrelatiecode: "OTHER", status: "Gepland", accommodatie: "Sportpark Houtrust", veld: "Veld 1" }] }, /* @__PURE__ */ new Date(17924904e5));
(0, import_node_fs.writeFileSync)("/dev/shm/duindorpsv-public-hero-still-IB2leK/fixture.json", JSON.stringify({ state, items: cmsArticlesForSite(state), slider, cards: defaultHeroCards, media, sportlink }, null, 2));
